expand.cfg
