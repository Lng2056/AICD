;;  Technology file for Library gpdk090 assembled on Tue Nov 22 15:25:07 EST 2005 
;;; Adding file(size date name): cadence1 20382 Nov 22 controls.tf
;;; Adding file(size date name): cadence1 37471 Nov 22 layerDefinitions.tf.cdba
;;; Adding file(size date name): cadence1 11481 Nov 22 layerRules.tf.cdba
;;; Adding file(size date name): cadence1 15425 Nov 22 physicalRules.tf.cdba
;;; Adding file(size date name): cadence1 4687 Nov 22 electricalRules.tf
;;; Adding file(size date name): cadence1 7293 Nov 22 devices.tf.cdba
;;; Adding file(size date name): cadence1 1307 Nov 22 compactorRules.tf
;;; Adding file(size date name): cadence1 6629 Nov 22 lxRules.tf
;;; Adding file(size date name): cadence1 21 Nov 22 leRules.tf
;;; Adding file(size date name): cadence1 3556 Nov 22 prRules.tf.cdba

;********************************
; CONTROLS
;********************************
controls(
    techParams(
;       ( parameter       value            )
;       ( ---------       -----            )
        ( NBLW1           3.2              )
        ( NBLE1           0.4              )
        ( NBLSP1          5.0              )
        ( NBLSE1          4.4              )
        ( NBLSE2          2.2              )
        ( NBLSE3          0.5              )
        ( NBLSE4          0.4              )
        ( NWSP1           0.6              )
        ( NWSP2           1.2              )
        ( NWW1            0.6              )
        ( NWSE1           0.3              )
        ( NWSE2           0.3              )
        ( NWSE3           0.5              )
        ( NWSE4           0.5              )
        ( NWE1            0.12             )
        ( NWE2            0.12             )
        ( NWE3            0.7              )
        ( NWE4            0.7              )
        ( NWRSE1          0.32             )
        ( NWRE1           1.2              )
        ( NWRE2           0.32             )
        ( NWRO1           0.45             )
        ( OXIDEW1         0.1              )
        ( OXIDEW211       0.12             )
        ( OXIDEW212       0.15             )
        ( OXIDEW221       0.12             )
        ( OXIDEW222       0.15             )
        ( OXIDEW3         0.13             )
        ( OXIDESP1        0.15             )
        ( OXIDESP2        0.15             )
        ( OXIDESP3        0.18             )
        ( OXIDESE1        0.28             )
        ( OXIDESP4        0.18             )
        ( OXIDEA1         0.06             )
        ( OXIDEEA1        0.10             )
        ( OXIDERW11       0.2              )
        ( OXIDERSE1       0.25             )
        ( OXIDERSE2       0.3              )
        ( OXIDERE1        0.25             )
        ( OXIDETHKW1      0.7              )
        ( OXIDETHKSP1     0.35             )
        ( OXIDETHKSP2     0.75             )
        ( OXIDETHKSE1     0.20             )
        ( OXIDETHKSE2     0.20             )
        ( OXIDETHKSE3     0.25             )
        ( OXIDETHKE1      0.30             )
        ( OXIDETHKSE5     0.34             )
        ( OXIDETHKE2      0.36             )
        ( NZVTW1          0.7              )
        ( NZVTSP1         0.6              )
        ( NZVTSE1         0.4              )
        ( NZVTSE2         1.2              )
        ( NZVTE1          0.2              )
        ( NZVTL1          0.9              )
        ( NZVTW2          0.65             )
        ( POLYW1          0.1              )
        ( POLYW2          0.1              )
        ( POLYW3          0.28             )
        ( POLYW4          0.28             )
        ( POLYW5          0.1              )
        ( POLYSP1         0.6              )
        ( POLYSP2         0.12             )
        ( POLYSP3         0.12             )
        ( POLYE1          0.18             )
        ( POLYE2          0.18             )
        ( POLYSE1_POLYSE2 0.1              )
        ( POLYE3          0.2              )
        ( POLYW6          0.18             )
        ( POLYSP4         0.22             )
        ( POLYX1          0                )
        ( POLYX2          0                )
        ( POLYA1          0.1              )
        ( POLYRW11        0.2              )
        ( POLYRSE1        0.25             )
        ( POLYRE1         0.28             )
        ( POLYRE2         0.15             )
        ( POLYRE3         0.15             )
        ( NIMPW1          0.24             )
        ( NIMPSP1         0.24             )
        ( NIMPE1          0.14             )
        ( NIMPO1          0.16             )
        ( NIMPSE1         0.16             )
        ( NIMPE2          0.02             )
        ( NIMPE3          0.18             )
        ( NIMPE4          0.18             )
        ( NIMPSE2         0.02             )
        ( NIMPA1          0.15             )
        ( NIMPEA1         0.16             )
        ( NIMPSE3         0.18             )
        ( PIMPW1          0.24             )
        ( PIMPSP1         0.24             )
        ( PIMPE1          0.14             )
        ( PIMPO1          0.16             )
        ( PIMPSE1         0.16             )
        ( PIMPE2          0.02             )
        ( PIMPE3          0.18             )
        ( PIMPE4          0.18             )
        ( PIMPSE2         0.02             )
        ( PIMPA1          0.15             )
        ( PIMPEA1         0.16             )
        ( PIMPSE3         0.18             )
        ( CONTW1          0.12             )
        ( CONTSP1         0.14             )
        ( CONTSP2         0.16             )
        ( CONTSE1         0.10             )
        ( CONTSE2         0.12             )
        ( CONTSE3         0.12             )
        ( CONTSE4         0.14             )
        ( CONTE1          0.06             )
        ( CONTE2          0.04             )
        ( CONTE3          0.06             )
        ( CONTE4          0.06             )
        ( CONTSE5         0.2              )
        ( CONTX2          0.005            )
        ( SIPROTW1        0.44             )
        ( SIPROTSP1       0.44             )
        ( SIPROTSE1       0.24             )
        ( SIPROTSE2       0.24             )
        ( SIPROTSE3       0.44             )
        ( SIPROTE2        0.24             )
        ( SIPROTE1        0.25             )
        ( SIPROTE3        0.28             )
        ( SIPROTA1        1.2              )
        ( SIPROTSE4       0.35             )
        ( SIPROTEA1       1.2              )
        ( METAL2E1        0.005            )
        ( METAL2E2        0.06             )
        ( METAL3E1        0.005            )
        ( METAL3E2        0.06             )
        ( METAL4E1        0.005            )
        ( METAL4E2        0.06             )
        ( METAL5E1        0.005            )
        ( METAL5E2        0.06             )
        ( METAL6E1        0.005            )
        ( METAL6E2        0.06             )
        ( METAL7E1        0.005            )
        ( METAL7E2        0.06             )
        ( METAL8E1        0.05             )
        ( METAL8E2        0.1              )
        ( METAL9E1        0.05             )
        ( METAL9E2        0.1              )
        ( METAL1E2        0.06             )
        ( METAL1W1        0.12             )
        ( METAL2W1        0.14             )
        ( METAL3W1        0.14             )
        ( METAL4W1        0.14             )
        ( METAL5W1        0.14             )
        ( METAL6W1        0.14             )
        ( METAL7W1        0.14             )
        ( METAL8W1        0.44             )
        ( METAL9W1        0.44             )
        ( METAL1W2        12.0             )
        ( METAL2W2        12.0             )
        ( METAL3W2        12.0             )
        ( METAL4W2        12.0             )
        ( METAL5W2        12.0             )
        ( METAL6W2        12.0             )
        ( METAL7W2        12.0             )
        ( METAL8W2        12.0             )
        ( METAL9W2        12.0             )
        ( METAL1SP11      0.12             )
        ( METAL2SP11      0.14             )
        ( METAL3SP11      0.14             )
        ( METAL4SP11      0.14             )
        ( METAL5SP11      0.14             )
        ( METAL6SP11      0.14             )
        ( METAL7SP11      0.14             )
        ( METAL8SP11      0.40             )
        ( METAL9SP11      0.40             )
        ( METAL1SP12      0.18             )
        ( METAL2SP12      0.20             )
        ( METAL3SP12      0.20             )
        ( METAL4SP12      0.20             )
        ( METAL5SP12      0.20             )
        ( METAL6SP12      0.20             )
        ( METAL7SP12      0.20             )
        ( METAL1SP13      0.50             )
        ( METAL2SP13      0.50             )
        ( METAL3SP13      0.50             )
        ( METAL4SP13      0.50             )
        ( METAL5SP13      0.50             )
        ( METAL6SP13      0.50             )
        ( METAL7SP13      0.50             )
        ( METAL8SP12      0.50             )
        ( METAL9SP12      0.50             )
        ( METAL1SP14      0.90             )
        ( METAL2SP14      0.90             )
        ( METAL3SP14      0.90             )
        ( METAL4SP14      0.90             )
        ( METAL5SP14      0.90             )
        ( METAL6SP14      0.90             )
        ( METAL7SP14      0.90             )
        ( METAL8SP13      0.90             )
        ( METAL9SP13      0.90             )
        ( METAL1SP15      1.50             )
        ( METAL2SP15      1.50             )
        ( METAL3SP15      1.50             )
        ( METAL4SP15      1.50             )
        ( METAL5SP15      1.50             )
        ( METAL6SP15      1.50             )
        ( METAL7SP15      1.50             )
        ( METAL8SP14      1.50             )
        ( METAL9SP14      1.50             )
        ( METAL1SP16      2.50             )
        ( METAL2SP16      2.50             )
        ( METAL3SP16      2.50             )
        ( METAL4SP16      2.50             )
        ( METAL5SP16      2.50             )
        ( METAL6SP16      2.50             )
        ( METAL7SP16      2.50             )
        ( METAL8SP15      2.50             )
        ( METAL9SP15      2.50             )
        ( METAL1L1        0.18             )
        ( METAL2L1        0.20             )
        ( METAL3L1        0.20             )
        ( METAL4L1        0.20             )
        ( METAL5L1        0.20             )
        ( METAL6L1        0.20             )
        ( METAL7L1        0.20             )
        ( METAL1SP2       0.16             )
        ( METAL1W3        0.14             )
        ( METAL2SP2       0.18             )
        ( METAL2W3        0.16             )
        ( METAL3SP2       0.18             )
        ( METAL3W3        0.16             )
        ( METAL4SP2       0.18             )
        ( METAL4W3        0.16             )
        ( METAL5SP2       0.18             )
        ( METAL5W3        0.16             )
        ( METAL6SP2       0.18             )
        ( METAL6W3        0.16             )
        ( METAL7SP2       0.18             )
        ( METAL7W3        0.16             )
        ( METAL1A1        0.07             )
        ( METAL2A1        0.08             )
        ( METAL3A1        0.08             )
        ( METAL4A1        0.08             )
        ( METAL5A1        0.08             )
        ( METAL6A1        0.08             )
        ( METAL7A1        0.08             )
        ( METAL8A1        0.2              )
        ( METAL9A1        0.2              )
        ( VIA1W1          0.14             )
        ( VIA1SP1         0.15             )
        ( VIA1SP2         0.20             )
        ( VIA2W1          0.14             )
        ( VIA2SP1         0.15             )
        ( VIA2SP2         0.20             )
        ( VIA3W1          0.14             )
        ( VIA3SP1         0.15             )
        ( VIA3SP2         0.20             )
        ( VIA4W1          0.14             )
        ( VIA4SP1         0.15             )
        ( VIA4SP2         0.20             )
        ( VIA5W1          0.14             )
        ( VIA5SP1         0.15             )
        ( VIA5SP2         0.20             )
        ( VIA6W1          0.14             )
        ( VIA6SP1         0.15             )
        ( VIA6SP2         0.20             )
        ( VIA7W1          0.36             )
        ( VIA7SP1         0.36             )
        ( VIA8W1          0.36             )
        ( VIA8SP1         0.36             )
        ( VIA1E1          0.005            )
        ( VIA1E2          0.06             )
        ( VIA2E1          0.005            )
        ( VIA2E2          0.06             )
        ( VIA3E1          0.005            )
        ( VIA3E2          0.06             )
        ( VIA4E1          0.005            )
        ( VIA4E2          0.06             )
        ( VIA5E1          0.005            )
        ( VIA5E2          0.06             )
        ( VIA6E1          0.005            )
        ( VIA6E2          0.06             )
        ( VIA7E1          0.03             )
        ( VIA7E2          0.08             )
        ( VIA8E1          0.03             )
        ( VIA8E2          0.08             )
        ( LATCHUP1        25.0             )
        ( LATCHUP2        25.0             )
        ( LATCHUP3        18.0             )
        ( MSLOT1W1_MSLOT1L1 2.0              )
        ( MSLOT1SP1       0.12             )
        ( MSLOT2W1_MSLOT2L1 2.0              )
        ( MSLOT2SP1       0.14             )
        ( MSLOT3W1_MSLOT3L1 2.0              )
        ( MSLOT3SP1       0.14             )
        ( MSLOT4W1_MSLOT4L1 2.0              )
        ( MSLOT4SP1       0.14             )
        ( MSLOT5W1_MSLOT5L1 2.0              )
        ( MSLOT5SP1       0.14             )
        ( MSLOT6W1_MSLOT6L1 2.0              )
        ( MSLOT6SP1       0.14             )
        ( MSLOT7W1_MSLOT7L1 2.0              )
        ( MSLOT7SP1       0.14             )
        ( MSLOT8W1_MSLOT8L1 2.0              )
        ( MSLOT8SP1       0.44             )
        ( MSLOT9W1_MSLOT9L1 2.0              )
        ( MSLOT9SP1       0.44             )
        ( MSLOT1E1        0.12             )
        ( MSLOT2E1        0.14             )
        ( MSLOT3E1        0.14             )
        ( MSLOT4E1        0.14             )
        ( MSLOT5E1        0.14             )
        ( MSLOT6E1        0.14             )
        ( MSLOT7E1        0.14             )
        ( MSLOT8E1        0.44             )
        ( MSLOT9E1        0.44             )
        ( ESD1            15.0             )
        ( ESD11           0.05             )
        ( ESD12           1.8              )
        ( ESD13           1.8              )
        ( ESD14           0.4              )
        ( ESD15           0.25             )
        ( BONDPADW1       5.0              )
        ( BONDPADSP1      10.0             )
        ( BONDPADE1       2.2              )
        ( BONDPADSP2      3.0              )
        ( BONDPADB1       1.8              )
        ( id1             0.25             )
        ( BONDPADE2       2.0              )

       ( maskGrid       	0.005 )
       ( cadGrid        	0.005 )
       ( drcGrid        	0.005 )
       ( mfgGrid        	0.005 )
       ( scale          	1.0 )
       ( LEFDEF_MANUFACTURINGGRID	0.005 )
  ( iccHeader      	"; Translation Rules 2.0
; Title: icc.rules
; Technology File: gpdk090
; Creator: Rules Editor 5.12.41_USR1.7.42
; Creation Date: Jan 11 13:07:24 2005
; From: @(#)$CDS: icfb.exe version 5.1.2 12/06/2004 06:59 (cds125840) $
; User: johnag

" )
  ( iccRevision    	"2.0"           )
  ( iccLayers      	((("Metal9" "drawing") "metal" "horizontal" 0.44 0.44 nil t) (("Via8" "drawing") "cut" "off" 0.36 0.36 nil nil) (("Metal8" "drawing") "metal" "vertical" 0.44 0.44 nil t) (("Via7" "drawing") "cut" "off" 0.36 0.36 nil nil) (("Metal7" "drawing") "metal" "horizontal" 0.14 0.14 nil t) (("Via6" "drawing") "cut" "off" 0.14 0.15 nil nil) (("Metal6" "drawing") "metal" "vertical" 0.14 0.14 nil t) (("Via5" "drawing") "cut" "off" 0.14 0.15 nil nil) (("Metal5" "drawing") "metal" "horizontal" 0.14 0.14 nil t) (("Via4" "drawing") "cut" "off" 0.14 0.15 nil nil) (("Metal4" "drawing") "metal" "vertical" 0.14 0.14 nil t) (("Via3" "drawing") "cut" "off" 0.14 0.15 t t) (("Metal3" "drawing") "metal" "horizontal" 0.14 0.14 nil t) (("Via2" "drawing") "cut" "off" 0.14 0.15 t t) (("Metal2" "drawing") "metal" "vertical" 0.14 0.14 nil t) (("Via1" "drawing") "cut" "off" 0.14 0.15 t t) (("Metal1" "drawing") "metal" "horizontal" 0.12 0.12 nil t) (("Cont" "drawing") "cut" "off" 0.12 0.14 t t) (("Poly" "drawing") "polysilicon" "orthogonal" 0.1 0.12 nil t) (("Oxide" "drawing") "n_diffusion" "off" 0.1 0.15 t t))	 )
  ( iccVias        	((("gpdk090" "M2_M1" "symbolic") t) (("gpdk090" "M3_M2" "symbolic") t) (("gpdk090" "M4_M3" "symbolic") t) (("gpdk090" "M5_M4" "symbolic") nil) (("gpdk090" "M6_M5" "symbolic") nil) (("gpdk090" "M7_M6" "symbolic") nil) (("gpdk090" "M8_M7" "symbolic") nil) (("gpdk090" "M9_M8" "symbolic") nil) (("gpdk090" "M1_PO" "symbolic") t))	 )
  ( iccEquivalentLayers	((("Metal9" "drawing") ("Metal9" "boundary") ("Metal9" "pin")) (("Via8" "drawing") ("Via8" "boundary")) (("Metal8" "drawing") ("Metal8" "boundary") ("Metal8" "pin")) (("Via7" "drawing") ("Via7" "boundary")) (("Metal7" "drawing") ("Metal7" "boundary") ("Metal7" "pin")) (("Via6" "drawing") ("Via6" "boundary")) (("Metal6" "drawing") ("Metal6" "boundary") ("Metal6" "pin")) (("Via5" "drawing") ("Via5" "boundary")) (("Metal5" "drawing") ("Metal5" "boundary") ("Metal5" "pin")) (("Via4" "drawing") ("Via4" "boundary")) (("Metal4" "drawing") ("Metal4" "boundary") ("Metal4" "pin")) (("Via3" "drawing") ("Via3" "boundary")) (("Metal3" "drawing") ("Metal3" "boundary") ("Metal3" "pin")) (("Via2" "drawing") ("Via2" "boundary")) (("Metal2" "drawing") ("Metal2" "boundary") ("Metal2" "pin")) (("Via1" "drawing") ("Via1" "boundary")) (("Metal1" "drawing") ("Metal1" "boundary") ("Metal1" "pin")) (("Cont" "drawing") ("Cont" "boundary")) (("Poly" "drawing") ("Poly" "boundary") ("Poly" "pin")) (("Oxide" "drawing") ("Oxide_thk" "drawing")))	 )
  ( iccBoundaryLayers	((("Metal9" "drawing") ("prBoundary" "drawing") 0.0) (("Via8" "drawing") ("prBoundary" "drawing") 0.0) (("Metal8" "drawing") ("prBoundary" "drawing") 0.0) (("Via7" "drawing") ("prBoundary" "drawing") 0.0) (("Metal7" "drawing") ("prBoundary" "drawing") 0.0) (("Via6" "drawing") ("prBoundary" "drawing") 0.0) (("Metal6" "drawing") ("prBoundary" "drawing") 0.0) (("Via5" "drawing") ("prBoundary" "drawing") 0.0) (("Metal5" "drawing") ("prBoundary" "drawing") 0.0) (("Via4" "drawing") ("prBoundary" "drawing") 0.0) (("Metal4" "drawing") ("prBoundary" "drawing") 0.0) (("Via3" "drawing") ("prBoundary" "drawing") 0.0) (("Metal3" "drawing") ("prBoundary" "drawing") 0.0) (("Via2" "drawing") ("prBoundary" "drawing") 0.0) (("Metal2" "drawing") ("prBoundary" "drawing") 0.0) (("Via1" "drawing") ("prBoundary" "drawing") 0.0) (("Metal1" "drawing") ("prBoundary" "drawing") 0.0) (("Cont" "drawing") ("prBoundary" "drawing") 0.0) (("Poly" "drawing") ("prBoundary" "drawing") 0.0) (("Oxide" "drawing") ("prBoundary" "drawing") 0.0))	 )
  ( iccKeepouts    	((nil (("=>" (("INDdummy" "drawing")) ("Metal9" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Metal8" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Metal7" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Metal6" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Metal5" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Metal4" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Metal3" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Metal2" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Metal1" "drawing") "routing" t) ("=>" (("INDdummy" "drawing")) ("Poly" "drawing") "routing" t) ("=>" (("Capdum" "drawing")) ("Via1" "drawing") "routing" t) ("=>" (("Cap3dum" "drawing")) ("Via1" "drawing") "routing" t) ("or" (("Oxide" "drawing") ("Oxide_thk" "drawing")) ("Poly" "drawing") "routing" t)) 32) nil)	 )
  ( iccConductors  	(nil nil)	 )
 ) ;techParams

 techPermissions(
 ;( class               (read-only users)  (read & write users)           )
 ;( ----------          -----------------  --------------------           )
 ) ;techPermissions
 
  viewTypeUnits(
 ;( viewType            userUnit        dbuperuu                  )
 ;( --------            --------        --------                  )
  ( maskLayout          "micron"        2000            )
  ( schematic           "inch"          160             )
  ( schematicSymbol     "inch"          160             )
  ( netlist             "inch"          160             )
 ) ;viewTypeUnits
 
) ;controls

;********************************
; LAYER DEFINITION (post lef-in version)
;********************************
layerDefinitions(

 techPurposes(
 ;( PurposeName               Purpose#   Abbreviation )
 ;( -----------               --------   ------------ )
 ;User-Defined Purposes:
  ( slot                      1                       )
  ( port                      12         pt0          )
  ( port1                     2          pt1          )
  ( region                    3          reg          )
  ( grid                      4          grd          )
  ( ppath                     5          pp0          )
  ( ppath1                    6          pp1          )
  ( macro                     7          mac          )
  ( nwell                     8          nwl          )
  ( dnwell                    9          dnw          )
  ( ipwell                    10         ipw          )
  ( GeoShare                  11         geo          )
 ;System-Reserved Purposes:
  ( warning                   234        wng          )
  ( tool1                     235        tl1          )
  ( tool0                     236        tl0          )
  ( label                     237        lbl          )
  ( flight                    238        flt          )
  ( error                     239        err          )
  ( annotate                  240        ant          )
  ( drawing1                  241        dr1          )
  ( drawing2                  242        dr2          )
  ( drawing3                  243        dr3          )
  ( drawing4                  244        dr4          )
  ( drawing5                  245        dr5          )
  ( drawing6                  246        dr6          )
  ( drawing7                  247        dr7          )
  ( drawing8                  248        dr8          )
  ( drawing9                  249        dr9          )
  ( boundary                  250        bnd          )
  ( pin                       251        pin          )
  ( drawing                   252        drw          )
  ( net                       253        net          )
  ( cell                      254        cel          )
  ( all                       255        all          )
 ) ;techPurposes

 techLayers(
 ;( LayerName                 Layer#     Abbreviation )
 ;( ---------                 ------     ------------ )
 ;User-Defined Layers:
  ( OVERLAP                   0          OVERLAP      )
  ( Oxide                     2          Oxide        )
  ( Oxide_thk                 4          Oxide_thk    )
  ( Nwell                     6          Nwell        )
  ( Poly                      10         Poly         )
  ( Nhvt                      11         Nhvt         )
  ( Nimp                      12         Nimp         )
  ( Phvt                      13         Phvt         )
  ( Pimp                      14         Pimp         )
  ( Nzvt                      15         Nzvt         )
  ( SiProt                    16         SiProt       )
  ( Nburied                   18         Nburied      )
  ( Cont                      20         Cont         )
  ( SNA                       24         SNA          )
  ( Metal1                    30         Metal1       )
  ( Via1                      32         Via1         )
  ( Metal2                    34         Metal2       )
  ( Via2                      36         Via2         )
  ( Metal3                    38         Metal3       )
  ( Via3                      40         Via3         )
  ( Metal4                    42         Metal4       )
  ( Via4                      44         Via4         )
  ( Metal5                    46         Metal5       )
  ( Via5                      48         Via5         )
  ( Metal6                    50         Metal6       )
  ( Via6                      52         Via6         )
  ( Metal7                    54         Metal7       )
  ( Via7                      56         Via7         )
  ( Metal8                    58         Metal8       )
  ( Via8                      60         Via8         )
  ( Metal9                    62         Metal9       )
  ( Metal1_slot               71         M1slot       )
  ( Metal2_slot               72         M2slot       )
  ( Metal3_slot               73         M3slot       )
  ( Metal4_slot               74         M4slot       )
  ( Metal5_slot               75         M5slot       )
  ( Metal6_slot               76         M6slot       )
  ( Metal7_slot               77         M7slot       )
  ( Metal8_slot               78         M8slot       )
  ( Metal9_slot               79         M9slot       )
  ( Psub                      80         Psub         )
  ( DIOdummy                  82         DIOdum       )
  ( PNPdummy                  84         PNPdum       )
  ( NPNdummy                  86         NPNdum       )
  ( IND2dummy                 88         IND2dum      )
  ( INDdummy                  90         INDdum       )
  ( BJTdum                    92         BJTdum       )
  ( Cap3dum                   93         Cap3dum      )
  ( Resdum                    94         Resdum       )
  ( Bondpad                   95         Bondpad      )
  ( Capdum                    96         Capdum       )
  ( CapMetal                  97         CapMetal     )
  ( ResWdum                   98         ResWdum      )
  ( M1Resdum                  99         M1Resdum     )
  ( M2Resdum                  100        M2Resdum     )
  ( M3Resdum                  101        M3Resdum     )
  ( M4Resdum                  102        M4Resdum     )
  ( M5Resdum                  103        M5Resdum     )
  ( M6Resdum                  104        M6Resdum     )
  ( M7Resdum                  105        M7Resdum     )
  ( M8Resdum                  106        M8Resdum     )
  ( M9Resdum                  107        M9Resdum     )
  ( VPNP2dum                  108        VPNP2dum     )
  ( VPNP5dum                  109        VPNP5dum     )
  ( VPNP10dum                 110        VPNP10dum    )
  ( IND3dummy                 114        IND3dum      )
  ( ESDdummy                  115        ESDdum       )
  ( allGeoShare               116        allGeo       )
 ;System-Reserved Layers:
  ( Unrouted                  200        Unroute      )
  ( Row                       201        Row          )
  ( Group                     202        Group        )
  ( Cannotoccupy              203        noOcupy      )
  ( Canplace                  204        Canplac      )
  ( hardFence                 205        hardFnc      )
  ( softFence                 206        softFnc      )
  ( y0                        207        y0           )
  ( y1                        208        y1           )
  ( y2                        209        y2           )
  ( y3                        210        y3           )
  ( y4                        211        y4           )
  ( y5                        212        y5           )
  ( y6                        213        y6           )
  ( y7                        214        y7           )
  ( y8                        215        y8           )
  ( y9                        216        y9           )
  ( designFlow                217        dsnFlow      )
  ( stretch                   218        stretch      )
  ( edgeLayer                 219        edgeLyr      )
  ( changedLayer              220        chngLyr      )
  ( unset                     221        unset        )
  ( unknown                   222        unknown      )
  ( spike                     223        spike        )
  ( hiz                       224        hiz          )
  ( resist                    225        resist       )
  ( drive                     226        drive        )
  ( supply                    227        supply       )
  ( wire                      228        wire         )
  ( pin                       229        pin          )
  ( text                      230        text         )
  ( device                    231        device       )
  ( border                    232        border       )
  ( snap                      233        snap         )
  ( align                     234        align        )
  ( prBoundary                235        prBndry      )
  ( instance                  236        instnce      )
  ( annotate                  237        anotate      )
  ( marker                    238        marker       )
  ( select                    239        select       )
  ( grid                      251        grid         )
  ( axis                      252        axis         )
  ( hilite                    253        hilite       )
  ( background                254        bkground     )
 ) ;techLayers

 techLayerPurposePriorities(
 ;layers are ordered from lowest to highest priority
 ;( LayerName                 Purpose    )
 ;( ---------                 -------    )
  ( OVERLAP                   boundary   )
  ( Nwell                     drawing    )
  ( Oxide                     drawing    )
  ( Oxide_thk                 drawing    )
  ( Poly                      drawing    )
  ( Pimp                      drawing    )
  ( Nhvt                      drawing    )
  ( Nimp                      drawing    )
  ( Phvt                      drawing    )
  ( Nzvt                      drawing    )
  ( SiProt                    drawing    )
  ( Cont                      drawing    )
  ( Metal1                    drawing    )
  ( Via1                      drawing    )
  ( Metal2                    drawing    )
  ( Via2                      drawing    )
  ( Metal3                    drawing    )
  ( Via3                      drawing    )
  ( Metal4                    drawing    )
  ( Via4                      drawing    )
  ( Metal5                    drawing    )
  ( Via5                      drawing    )
  ( Metal6                    drawing    )
  ( Via6                      drawing    )
  ( Metal7                    drawing    )
  ( Via7                      drawing    )
  ( Metal8                    drawing    )
  ( Via8                      drawing    )
  ( Metal9                    drawing    )
  ( CapMetal                  drawing    )
  ( Nburied                   drawing    )
  ( Psub                      drawing    )
  ( Metal1                    slot       )
  ( Metal2                    slot       )
  ( Metal3                    slot       )
  ( Metal4                    slot       )
  ( Metal5                    slot       )
  ( Metal6                    slot       )
  ( Metal7                    slot       )
  ( Metal8                    slot       )
  ( Metal9                    slot       )
  ( Bondpad                   drawing    )
  ( Capdum                    drawing    )
  ( Cap3dum                   drawing    )
  ( INDdummy                  drawing    )
  ( IND2dummy                 drawing    )
  ( IND3dummy                 drawing    )
  ( Resdum                    drawing    )
  ( ResWdum                   drawing    )
  ( M1Resdum                  drawing    )
  ( M2Resdum                  drawing    )
  ( M3Resdum                  drawing    )
  ( M4Resdum                  drawing    )
  ( M5Resdum                  drawing    )
  ( M6Resdum                  drawing    )
  ( M7Resdum                  drawing    )
  ( M8Resdum                  drawing    )
  ( M9Resdum                  drawing    )
  ( BJTdum                    drawing    )
  ( VPNP2dum                  drawing    )
  ( VPNP5dum                  drawing    )
  ( VPNP10dum                 drawing    )
  ( NPNdummy                  drawing    )
  ( PNPdummy                  drawing    )
  ( DIOdummy                  drawing    )
  ( ESDdummy                  drawing    )
  ( text                      drawing    )
  ( Metal1                    label      )
  ( Metal2                    label      )
  ( Metal3                    label      )
  ( Metal4                    label      )
  ( Metal5                    label      )
  ( Metal6                    label      )
  ( Metal7                    label      )
  ( Metal8                    label      )
  ( Metal9                    label      )
  ( background                drawing    )
  ( grid                      drawing    )
  ( grid                      drawing1   )
  ( annotate                  drawing    )
  ( annotate                  drawing1   )
  ( annotate                  drawing2   )
  ( annotate                  drawing3   )
  ( annotate                  drawing4   )
  ( annotate                  drawing5   )
  ( annotate                  drawing6   )
  ( annotate                  drawing7   )
  ( annotate                  drawing8   )
  ( annotate                  drawing9   )
  ( instance                  drawing    )
  ( instance                  label      )
  ( prBoundary                drawing    )
  ( prBoundary                boundary   )
  ( prBoundary                label      )
  ( align                     drawing    )
  ( hardFence                 drawing    )
  ( softFence                 drawing    )
  ( text                      drawing1   )
  ( text                      drawing2   )
  ( border                    drawing    )
  ( device                    drawing    )
  ( device                    label      )
  ( device                    drawing1   )
  ( device                    drawing2   )
  ( device                    annotate   )
  ( wire                      drawing    )
  ( wire                      label      )
  ( wire                      flight     )
  ( pin                       label      )
  ( pin                       drawing    )
  ( pin                       annotate   )
  ( axis                      drawing    )
  ( edgeLayer                 drawing    )
  ( edgeLayer                 pin        )
  ( snap                      boundary   )
  ( snap                      drawing    )
  ( Nwell                     net        )
  ( Oxide_thk                 net        )
  ( Oxide                     net        )
  ( Pimp                      net        )
  ( Nimp                      net        )
  ( Poly                      net        )
  ( Cont                      net        )
  ( Metal1                    boundary   )
  ( Metal1                    pin        )
  ( Metal1                    net        )
  ( Via1                      slot       )
  ( Via1                      boundary   )
  ( Via1                      pin        )
  ( Via1                      net        )
  ( Metal2                    boundary   )
  ( Metal2                    pin        )
  ( Metal2                    net        )
  ( Via2                      slot       )
  ( Via2                      boundary   )
  ( Via2                      pin        )
  ( Via2                      net        )
  ( Metal3                    boundary   )
  ( Metal3                    pin        )
  ( Metal3                    net        )
  ( Via3                      slot       )
  ( Via3                      boundary   )
  ( Via3                      pin        )
  ( Via3                      net        )
  ( Metal4                    boundary   )
  ( Metal4                    pin        )
  ( Metal4                    net        )
  ( Via4                      slot       )
  ( Via4                      boundary   )
  ( Via4                      pin        )
  ( Via4                      net        )
  ( Metal5                    boundary   )
  ( Metal5                    pin        )
  ( Metal5                    net        )
  ( Via5                      slot       )
  ( Via5                      boundary   )
  ( Via5                      pin        )
  ( Via5                      net        )
  ( Metal6                    boundary   )
  ( Metal6                    pin        )
  ( Metal6                    net        )
  ( Via6                      slot       )
  ( Via6                      boundary   )
  ( Via6                      pin        )
  ( Via6                      net        )
  ( Metal7                    boundary   )
  ( Metal7                    pin        )
  ( Metal7                    net        )
  ( Via7                      slot       )
  ( Via7                      boundary   )
  ( Via7                      pin        )
  ( Via7                      net        )
  ( Metal8                    boundary   )
  ( Metal8                    pin        )
  ( Metal8                    net        )
  ( Via8                      slot       )
  ( Via8                      boundary   )
  ( Via8                      pin        )
  ( Via8                      net        )
  ( Metal9                    boundary   )
  ( Metal9                    pin        )
  ( Metal9                    net        )
  ( stretch                   drawing    )
  ( y0                        drawing    )
  ( y1                        drawing    )
  ( y2                        drawing    )
  ( y3                        drawing    )
  ( y4                        drawing    )
  ( y5                        drawing    )
  ( y6                        drawing    )
  ( y7                        drawing    )
  ( y8                        drawing    )
  ( y9                        drawing    )
  ( hilite                    drawing    )
  ( hilite                    drawing1   )
  ( hilite                    drawing2   )
  ( hilite                    drawing3   )
  ( hilite                    drawing4   )
  ( hilite                    drawing5   )
  ( hilite                    drawing6   )
  ( hilite                    drawing7   )
  ( hilite                    drawing8   )
  ( hilite                    drawing9   )
  ( select                    drawing    )
  ( drive                     drawing    )
  ( hiz                       drawing    )
  ( resist                    drawing    )
  ( spike                     drawing    )
  ( supply                    drawing    )
  ( unknown                   drawing    )
  ( unset                     drawing    )
  ( designFlow                drawing    )
  ( designFlow                drawing1   )
  ( designFlow                drawing2   )
  ( designFlow                drawing3   )
  ( designFlow                drawing4   )
  ( designFlow                drawing5   )
  ( designFlow                drawing6   )
  ( designFlow                drawing7   )
  ( designFlow                drawing8   )
  ( designFlow                drawing9   )
  ( changedLayer              tool0      )
  ( changedLayer              tool1      )
  ( marker                    warning    )
  ( marker                    error      )
  ( Row                       drawing    )
  ( Row                       label      )
  ( Row                       boundary   )
  ( Group                     drawing    )
  ( Group                     label      )
  ( Cannotoccupy              drawing    )
  ( Cannotoccupy              boundary   )
  ( Canplace                  drawing    )
  ( Unrouted                  drawing    )
  ( Unrouted                  drawing1   )
  ( Unrouted                  drawing2   )
  ( Unrouted                  drawing3   )
  ( Unrouted                  drawing4   )
  ( Unrouted                  drawing5   )
  ( Unrouted                  drawing6   )
  ( Unrouted                  drawing7   )
  ( Unrouted                  drawing8   )
  ( Unrouted                  drawing9   )
  ( SNA                       region     )
  ( SNA                       port       )
  ( SNA                       port1      )
  ( SNA                       drawing9   )
  ( SNA                       drawing8   )
  ( SNA                       drawing7   )
  ( SNA                       drawing6   )
  ( SNA                       drawing5   )
  ( SNA                       drawing4   )
  ( SNA                       drawing3   )
  ( SNA                       drawing2   )
  ( SNA                       drawing1   )
  ( SNA                       drawing    )
  ( SNA                       grid       )
  ( SNA                       ppath      )
  ( SNA                       ppath1     )
  ( SNA                       label      )
  ( SNA                       macro      )
  ( SNA                       nwell      )
  ( SNA                       dnwell     )
  ( SNA                       ipwell     )
  ( allGeoShare               GeoShare   )
 ) ;techLayerPurposePriorities

 techDisplays(
 ;( LayerName    Purpose      Packet          Vis Sel Con2ChgLy DrgEnbl Valid )
 ;( ---------    -------      ------          --- --- --------- ------- ----- )
  ( OVERLAP      boundary     defaultPacket    t t t t nil)
  ( Nwell        drawing      nwell            t t t t t )
  ( Nwell        net          nwell_net        t t t t t )
  ( Oxide        drawing      tox              t t t t t )
  ( Oxide        net          tox_net          t t t t t )
  ( Oxide_thk    drawing      Oxide_thk        t t t t t )
  ( Oxide_thk    net          Oxide_thk_net    t t t t t )
  ( Poly         drawing      poly1            t t t t t )
  ( Poly         net          poly1_net        t t t t t )
  ( Pimp         drawing      pplus            t t t t t )
  ( Pimp         net          pplus_net        t t t t t )
  ( Nhvt         drawing      nhvt             t t t t t )
  ( Nimp         drawing      nplus            t t t t t )
  ( Nimp         net          nplus_net        t t t t t )
  ( Phvt         drawing      phvt             t t t t t )
  ( Nzvt         drawing      Nzvt             t t t t t )
  ( SiProt       drawing      siprot           t t t t t )
  ( Cont         drawing      cw               t t t t t )
  ( Cont         net          cw_net           t t t t t )
  ( Metal1       drawing      m1               t t t t t )
  ( Via1         drawing      v1               t t t t t )
  ( Metal2       drawing      m2               t t t t t )
  ( Via2         drawing      v2               t t t t t )
  ( Metal3       drawing      m3               t t t t t )
  ( Via3         drawing      v3               t t t t t )
  ( Metal4       drawing      m4               t t t t t )
  ( Via4         drawing      v4               t t t t t )
  ( Metal5       drawing      m5               t t t t t )
  ( Via5         drawing      v5               t t t t t )
  ( Metal6       drawing      m6               t t t t t )
  ( Via6         drawing      v6               t t t t t )
  ( Metal7       drawing      m7               t t t t t )
  ( Via7         drawing      v7               t t t t t )
  ( Metal8       drawing      m8               t t t t t )
  ( Via8         drawing      v8               t t t t t )
  ( Metal9       drawing      m9               t t t t t )
  ( CapMetal     drawing      mcap             t t t t t )
  ( Nburied      drawing      npblk            t t t t t )
  ( Psub         drawing      psub             t t t t t )
  ( Metal1       slot         m1_slot          t t t t t )
  ( Metal2       slot         m2_slot          t t t t t )
  ( Metal3       slot         m3_slot          t t t t t )
  ( Metal4       slot         m4_slot          t t t t t )
  ( Metal5       slot         m5_slot          t t t t t )
  ( Metal6       slot         m6_slot          t t t t t )
  ( Metal7       slot         m7_slot          t t t t t )
  ( Metal8       slot         m8_slot          t t t t t )
  ( Metal9       slot         m9_slot          t t t t t )
  ( Bondpad      drawing      pass             t t t t t )
  ( Capdum       drawing      zcap             t t t t t )
  ( Cap3dum      drawing      zcap             t t t t t )
  ( INDdummy     drawing      zind             t t t t t )
  ( IND2dummy    drawing      zind2            t t t t t )
  ( IND3dummy    drawing      zind3            t t t t t )
  ( Resdum       drawing      zrpoly           t t t t t )
  ( ResWdum      drawing      zrwell           t t t t t )
  ( M1Resdum     drawing      zrm1             t t t t t )
  ( M2Resdum     drawing      zrm2             t t t t t )
  ( M3Resdum     drawing      zrm3             t t t t t )
  ( M4Resdum     drawing      zrm4             t t t t t )
  ( M5Resdum     drawing      zrm5             t t t t t )
  ( M6Resdum     drawing      zrm6             t t t t t )
  ( M7Resdum     drawing      zrm7             t t t t t )
  ( M8Resdum     drawing      zrm8             t t t t t )
  ( M9Resdum     drawing      zrm9             t t t t t )
  ( BJTdum       drawing      zbip             t t t t t )
  ( VPNP2dum     drawing      zvpnp2           t t t t t )
  ( VPNP5dum     drawing      zvpnp5           t t t t t )
  ( VPNP10dum    drawing      zvpnp10          t t t t t )
  ( NPNdummy     drawing      znpn             t t t t t )
  ( PNPdummy     drawing      zpnp             t t t t t )
  ( DIOdummy     drawing      zdiode           t t t t t )
  ( ESDdummy     drawing      esddum           t t t t t )
  ( text         drawing      text             t t t t t )
  ( Metal1       label        m1               t t t t t )
  ( Metal2       label        m2               t t t t t )
  ( Metal3       label        m3               t t t t t )
  ( Metal4       label        m4               t t t t t )
  ( Metal5       label        m5               t t t t t )
  ( Metal6       label        m6               t t t t t )
  ( Metal7       label        m7               t t t t t )
  ( Metal8       label        m8               t t t t t )
  ( Metal9       label        m9               t t t t t )
  ( background   drawing      background       t nil t nil nil )
  ( grid         drawing      grid             t nil t nil nil )
  ( grid         drawing1     grid1            t nil t nil nil )
  ( annotate     drawing      annotate         t t t t nil )
  ( annotate     drawing1     annotate1        t t t t nil )
  ( annotate     drawing2     annotate2        t t t t nil )
  ( annotate     drawing3     annotate3        t t t t nil )
  ( annotate     drawing4     annotate4        t t t t nil )
  ( annotate     drawing5     annotate5        t t t t nil )
  ( annotate     drawing6     annotate6        t t t t nil )
  ( annotate     drawing7     annotate7        t t t t nil )
  ( annotate     drawing8     annotate8        t t t t nil )
  ( annotate     drawing9     annotate9        t t t t nil )
  ( instance     drawing      instance         t t t t nil )
  ( instance     label        instanceLbl      t t t t nil )
  ( prBoundary   drawing      prBoundary       t t t t t )
  ( prBoundary   boundary     prBoundaryBnd    t t t t t )
  ( prBoundary   label        prBoundaryLbl    t t t t t )
  ( align        drawing      defaultPacket    t t t t nil )
  ( hardFence    drawing      hardFence        t t t t nil )
  ( softFence    drawing      softFence        t t t t nil )
  ( text         drawing1     text1            t t t t nil )
  ( text         drawing2     text2            t t t t nil )
  ( border       drawing      border           t t t t nil )
  ( device       drawing      device           t t t t nil )
  ( device       label        deviceLbl        t t t t nil )
  ( device       drawing1     device1          t t t t nil )
  ( device       drawing2     device2          t t t t nil )
  ( device       annotate     deviceAnt        t t t t nil )
  ( wire         drawing      wire             t t t t nil )
  ( wire         label        wireLbl          t t t t nil )
  ( wire         flight       wireFlt          t t t t nil )
  ( pin          label        pinLbl           t t t t nil )
  ( pin          drawing      pin              t t t t nil )
  ( pin          annotate     pinAnt           t t t t nil )
  ( axis         drawing      axis             t nil t t nil )
  ( edgeLayer    drawing      edgeLayer        t t t t nil )
  ( edgeLayer    pin          edgeLayerPin     t t t t nil )
  ( snap         boundary     snap             t t t t nil )
  ( snap         drawing      snap             t t t t nil )
  ( Metal1       boundary     Metal1_boundary  t t t t t )
  ( Metal1       pin          Metal1_pin       t t t t t )
  ( Metal1       net          Metal1_net       t t t t t )
  ( Via1         slot         Via1_slot        t t t t nil )
  ( Via1         boundary     Via1_boundary    t t t t nil )
  ( Via1         pin          Via1_pin         t t t t nil )
  ( Via1         net          Via1_net         t t t t nil )
  ( Metal2       boundary     Metal2_boundary  t t t t t )
  ( Metal2       pin          Metal2_pin       t t t t t )
  ( Metal2       net          Metal2_net       t t t t t )
  ( Via2         slot         Via2_slot        t t t t nil )
  ( Via2         boundary     Via2_boundary    t t t t nil )
  ( Via2         pin          Via2_pin         t t t t nil )
  ( Via2         net          Via2_net         t t t t nil )
  ( Metal3       boundary     Metal3_boundary  t t t t t )
  ( Metal3       pin          Metal3_pin       t t t t t )
  ( Metal3       net          Metal3_net       t t t t t )
  ( Via3         slot         Via3_slot        t t t t nil )
  ( Via3         boundary     Via3_boundary    t t t t nil )
  ( Via3         pin          Via3_pin         t t t t nil )
  ( Via3         net          Via3_net         t t t t nil )
  ( Metal4       boundary     Metal4_boundary  t t t t t )
  ( Metal4       pin          Metal4_pin       t t t t t )
  ( Metal4       net          Metal4_net       t t t t t )
  ( Via4         slot         Via4_slot        t t t t nil )
  ( Via4         boundary     Via4_boundary    t t t t nil )
  ( Via4         pin          Via4_pin         t t t t nil )
  ( Via4         net          Via4_net         t t t t nil )
  ( Metal5       boundary     Metal5_boundary  t t t t t )
  ( Metal5       pin          Metal5_pin       t t t t t )
  ( Metal5       net          Metal5_net       t t t t t )
  ( Via5         slot         Via5_slot        t t t t nil )
  ( Via5         boundary     Via5_boundary    t t t t nil )
  ( Via5         pin          Via5_pin         t t t t nil )
  ( Via5         net          Via5_net         t t t t nil )
  ( Metal6       boundary     Metal6_boundary  t t t t t )
  ( Metal6       pin          Metal6_pin       t t t t t )
  ( Metal6       net          Metal6_net       t t t t t )
  ( Via6         slot         Via6_slot        t t t t nil )
  ( Via6         boundary     Via6_boundary    t t t t nil )
  ( Via6         pin          Via6_pin         t t t t nil )
  ( Via6         net          Via6_net         t t t t nil )
  ( Metal7       boundary     Metal7_boundary  t t t t t )
  ( Metal7       pin          Metal7_pin       t t t t t )
  ( Metal7       net          Metal7_net       t t t t t )
  ( Via7         slot         Via7_slot        t t t t nil )
  ( Via7         boundary     Via7_boundary    t t t t nil )
  ( Via7         pin          Via7_pin         t t t t nil )
  ( Via7         net          Via7_net         t t t t nil )
  ( Metal8       boundary     Metal8_boundary  t t t t t )
  ( Metal8       pin          Metal8_pin       t t t t t )
  ( Metal8       net          Metal8_net       t t t t t )
  ( Via8         slot         Via8_slot        t t t t nil )
  ( Via8         boundary     Via8_boundary    t t t t nil )
  ( Via8         pin          Via8_pin         t t t t nil )
  ( Via8         net          Via8_net         t t t t nil )
  ( Metal9       boundary     Metal9_boundary  t t t t t )
  ( Metal9       pin          Metal9_pin       t t t t t )
  ( Metal9       net          Metal9_net       t t t t t )
  ( stretch      drawing      stretch          t t t t nil )
  ( y0           drawing      y0               t t t t nil )
  ( y1           drawing      y1               t t t t nil )
  ( y2           drawing      y2               t t t t nil )
  ( y3           drawing      y3               t t t t nil )
  ( y4           drawing      y4               t t t t nil )
  ( y5           drawing      y5               t t t t nil )
  ( y6           drawing      y6               t t t t nil )
  ( y7           drawing      y7               t t t t nil )
  ( y8           drawing      y8               t t t t nil )
  ( y9           drawing      y9               t t t t nil )
  ( hilite       drawing      hilite           t t t t nil )
  ( hilite       drawing1     hilite1          t t t t nil )
  ( hilite       drawing2     hilite2          t t t t nil )
  ( hilite       drawing3     hilite3          t t t t nil )
  ( hilite       drawing4     hilite4          t t t t nil )
  ( hilite       drawing5     hilite5          t t t t nil )
  ( hilite       drawing6     hilite6          t t t t nil )
  ( hilite       drawing7     hilite7          t t t t nil )
  ( hilite       drawing8     hilite8          t t t t nil )
  ( hilite       drawing9     hilite9          t t t t nil )
  ( select       drawing      select           t t t t nil )
  ( drive        drawing      drive            t t t t nil )
  ( hiz          drawing      hiz              t t t t nil )
  ( resist       drawing      resist           t t t t nil )
  ( spike        drawing      spike            t t t t nil )
  ( supply       drawing      supply           t t t t nil )
  ( unknown      drawing      unknown          t t t t nil )
  ( unset        drawing      unset            t t t t nil )
  ( designFlow   drawing      designFlow       t nil nil nil nil )
  ( designFlow   drawing1     designFlow1      t nil nil nil nil )
  ( designFlow   drawing2     designFlow2      t nil nil nil nil )
  ( designFlow   drawing3     designFlow3      t nil nil nil nil )
  ( designFlow   drawing4     designFlow4      t nil nil nil nil )
  ( designFlow   drawing5     designFlow5      t nil nil nil nil )
  ( designFlow   drawing6     designFlow6      t nil nil nil nil )
  ( designFlow   drawing7     designFlow7      t nil nil nil nil )
  ( designFlow   drawing8     designFlow8      t nil nil nil nil )
  ( designFlow   drawing9     designFlow9      t nil nil nil nil )
  ( changedLayer tool0        changedLayerTl0  nil nil t nil nil )
  ( changedLayer tool1        changedLayerTl1  nil nil t nil nil )
  ( marker       warning      markerWarn       t t t t nil )
  ( marker       error        markerErr        t t t t nil )
  ( Row          drawing      Row              t t t t nil )
  ( Row          label        RowLbl           t t t t nil )
  ( Row          boundary     RowBnd           nil t t t t )
  ( Group        drawing      Group            t t t t nil )
  ( Group        label        GroupLbl         t t t t nil )
  ( Cannotoccupy drawing      Cannotoccupy     t t t t nil )
  ( Cannotoccupy boundary     CannotoccupyBnd  t t t t nil )
  ( Canplace     drawing      Canplace         t t t t nil )
  ( Unrouted     drawing      Unrouted         t t t t nil )
  ( Unrouted     drawing1     Unrouted1        t t t t nil )
  ( Unrouted     drawing2     Unrouted2        t t t t nil )
  ( Unrouted     drawing3     Unrouted3        t t t t nil )
  ( Unrouted     drawing4     Unrouted4        t t t t nil )
  ( Unrouted     drawing5     Unrouted5        t t t t nil )
  ( Unrouted     drawing6     Unrouted6        t t t t nil )
  ( Unrouted     drawing7     Unrouted7        t t t t nil )
  ( Unrouted     drawing8     Unrouted8        t t t t nil )
  ( Unrouted     drawing9     Unrouted9        t t t t nil )
  ( SNA          region       SCRD             nil t t t t )
  ( SNA          port         SCAPD            nil t t t t )
  ( SNA          port1        SCAPD1           nil t t t t )
  ( SNA          drawing9     SCSDD9           nil t t t t )
  ( SNA          drawing8     SCSDD8           nil t t t t )
  ( SNA          drawing7     SCSDD7           nil t t t t )
  ( SNA          drawing6     SCSDD6           nil t t t t )
  ( SNA          drawing5     SCSDD5           nil t t t t )
  ( SNA          drawing4     SCSDD4           nil t t t t )
  ( SNA          drawing3     SCSDD3           nil t t t t )
  ( SNA          drawing2     SCSDD2           nil t t t t )
  ( SNA          drawing1     SCSDD1           nil t t t t )
  ( SNA          drawing      SCSDD0           nil t t t t )
  ( SNA          grid         SCSGD            nil t t t t )
  ( SNA          ppath        SCPPD            nil t t t t )
  ( SNA          ppath1       SCPPD1           nil t t t t )
  ( SNA          label        SCPPL            nil t t t t )
  ( SNA          macro        SCMAC            nil t t t t )
  ( SNA          nwell        SCRD             nil t t t t )
  ( SNA          dnwell       SCRD             nil t t t t )
  ( SNA          ipwell       SCRD             nil t t t t )
  ( allGeoShare  GeoShare     defaultPacket    nil t t t t )
 ) ;techDisplays

techLayerProperties(
;( PropName               Layer1 [ Layer2 ]            PropValue )
 ( iccMaskNumber          (Poly              drawing )   0 )
 ( iccMaskNumber          (Cont              drawing )   0 )
 ( iccMaskNumber          (Metal1            drawing )   0 )
 ( iccMaskNumber          (Via1              drawing )   0 )
 ( iccMaskNumber          (Metal2            drawing )   0 )
 ( iccMaskNumber          (Via2              drawing )   0 )
 ( iccMaskNumber          (Metal3            drawing )   0 )
 ( iccMaskNumber          (Via3              drawing )   0 )
 ( iccMaskNumber          (Metal4            drawing )   0 )
 ( iccMaskNumber          (Via4              drawing )   0 )
 ( iccMaskNumber          (Metal5            drawing )   0 )
 ( iccMaskNumber          (Via5              drawing )   0 )
 ( iccMaskNumber          (Metal6            drawing )   0 )
 ( prMaxStackVia          Metal1       Metal7            4 )
)

) ;layerDefinitions
;********************************
; LAYER RULES
;********************************
layerRules(

    streamLayers(
;       ( layer                           streamNumber    dataType        translate        )
;       ( -----                           ------------    --------        ---------        )
        ( ("Nwell" "drawing")             2               0               t                )
        ( ("Oxide" "drawing")             1               0               t                )
        ( ("Oxide_thk" "drawing")         24              0               t                )
        ( ("Poly" "drawing")              3               0               t                )
        ( ("Pimp" "drawing")              5               0               t                )
        ( ("Nhvt" "drawing")              18              0               t                )
        ( ("Nimp" "drawing")              4               0               t                )
        ( ("Phvt" "drawing")              23              0               t                )
        ( ("Nzvt" "drawing")              52              0               t                )
        ( ("SiProt" "drawing")            72              0               t                )
        ( ("Cont" "drawing")              6               0               t                )
        ( ("Metal1" "drawing")            7               0               t                )
        ( ("Via1" "drawing")              8               0               t                )
        ( ("Metal2" "drawing")            9               0               t                )
        ( ("Via2" "drawing")              10              0               t                )
        ( ("Metal3" "drawing")            11              0               t                )
        ( ("Via3" "drawing")              30              0               t                )
        ( ("Metal4" "drawing")            31              0               t                )
        ( ("Via4" "drawing")              32              0               t                )
        ( ("Metal5" "drawing")            33              0               t                )
        ( ("Via5" "drawing")              34              0               t                )
        ( ("Metal6" "drawing")            35              0               t                )
        ( ("Via6" "drawing")              37              0               t                )
        ( ("Metal7" "drawing")            38              0               t                )
        ( ("Via7" "drawing")              39              0               t                )
        ( ("Metal8" "drawing")            40              0               t                )
        ( ("Via8" "drawing")              41              0               t                )
        ( ("Metal9" "drawing")            42              0               t                )
        ( ("CapMetal" "drawing")          14              0               t                )
        ( ("Nburied" "drawing")           19              0               t                )
        ( ("Psub" "drawing")              25              0               t                )
        ( ("Metal1" "slot")               7               2               t                )
        ( ("Metal2" "slot")               9               2               t                )
        ( ("Metal3" "slot")               11              2               t                )
        ( ("Metal4" "slot")               31              2               t                )
        ( ("Metal5" "slot")               33              2               t                )
        ( ("Metal6" "slot")               35              2               t                )
        ( ("Metal7" "slot")               38              2               t                )
        ( ("Metal8" "slot")               40              2               t                )
        ( ("Metal9" "slot")               42              2               t                )
        ( ("Metal1" "pin")                7               1               t                )
        ( ("Metal2" "pin")                9               1               t                )
        ( ("Metal3" "pin")                11              1               t                )
        ( ("Metal4" "pin")                31              1               t                )
        ( ("Metal5" "pin")                33              1               t                )
        ( ("Metal6" "pin")                35              1               t                )
        ( ("Metal7" "pin")                38              1               t                )
        ( ("Metal8" "pin")                40              1               t                )
        ( ("Metal9" "pin")                42              1               t                )
        ( ("Metal1" "net")                7               1               t                )
        ( ("Metal2" "net")                9               1               t                )
        ( ("Metal3" "net")                11              1               t                )
        ( ("Metal4" "net")                31              1               t                )
        ( ("Metal5" "net")                33              1               t                )
        ( ("Metal6" "net")                35              1               t                )
        ( ("Metal7" "net")                38              1               t                )
        ( ("Metal8" "net")                40              1               t                )
        ( ("Metal9" "net")                42              1               t                )
        ( ("Bondpad" "drawing")           36              0               t                )
        ( ("Capdum" "drawing")            12              0               t                )
        ( ("Cap3dum" "drawing")           84              0               t                )
        ( ("INDdummy" "drawing")          16              0               t                )
        ( ("IND2dummy" "drawing")         17              0               t                )
        ( ("IND3dummy" "drawing")         70              0               t                )
        ( ("Resdum" "drawing")            13              0               t                )
        ( ("ResWdum" "drawing")           71              0               t                )
        ( ("M1Resdum" "drawing")          75              0               t                )
        ( ("M2Resdum" "drawing")          76              0               t                )
        ( ("M3Resdum" "drawing")          77              0               t                )
        ( ("M4Resdum" "drawing")          78              0               t                )
        ( ("M5Resdum" "drawing")          79              0               t                )
        ( ("M6Resdum" "drawing")          80              0               t                )
        ( ("M7Resdum" "drawing")          81              0               t                )
        ( ("M8Resdum" "drawing")          82              0               t                )
        ( ("M9Resdum" "drawing")          83              0               t                )
        ( ("BJTdum" "drawing")            15              0               t                )
        ( ("VPNP2dum" "drawing")          60              0               t                )
        ( ("VPNP5dum" "drawing")          61              0               t                )
        ( ("VPNP10dum" "drawing")         62              0               t                )
        ( ("NPNdummy" "drawing")          20              0               t                )
        ( ("PNPdummy" "drawing")          21              0               t                )
        ( ("DIOdummy" "drawing")          22              0               t                )
        ( ("ESDdummy" "drawing")          74              0               t                )
        ( ("text" "drawing")              63              0               t                )
        ( ("Metal1" "label")              7               3               t                )
        ( ("Metal2" "label")              9               3               t                )
        ( ("Metal3" "label")              11              3               t                )
        ( ("Metal4" "label")              31              3               t                )
        ( ("Metal5" "label")              33              3               t                )
        ( ("Metal6" "label")              35              3               t                )
        ( ("Metal7" "label")              38              3               t                )
        ( ("Metal8" "label")              40              3               t                )
        ( ("Metal9" "label")              42              3               t                )
        ( ("prBoundary" "drawing")        62              0               t                )
    ) ;streamLayers
 viaLayers(
 ;( layer1      viaLayer        layer2     )
 ;( ------      --------        ------     )
  ( Poly      	Cont      	Metal1     )
  ( Oxide     	Cont      	Metal1     )
  ( Metal1    	Via1      	Metal2     )
  ( Metal2    	Via2      	Metal3     )
  ( Metal3    	Via3      	Metal4     )
  ( Metal4    	Via4      	Metal5     )
  ( Metal5    	Via5      	Metal6     )
  ( Metal6    	Via6      	Metal7     )
  ( Metal7    	Via7      	Metal8     )
  ( Metal8    	Via8      	Metal9     )
 ) ;viaLayers

 layerFunctions(
 ;( layer                       function        [maskNumber])
 ;( -----                       --------        ------------)
  ( Psub                        "pwell"           1   )
  ( Nburied                     "nwell"           2   )
  ( Nwell                       "nwell"           3   )
  ( Oxide                       "ndiff"           4   ) 
  ( Oxide_thk                   "ndiff"           5   )
  ( Poly                        "poly"            6   ) 
  ( Nhvt                        "nplus"           7   )
  ( Nimp                        "nplus"           8   )
  ( Phvt                        "pplus"           9   )
  ( Pimp                        "pplus"           10  )
  ( Nzvt                        "nplus"           11  )
  ( SiProt                      "pplus"           12  )
  ( Cont                        "cut"             13  )
  ( Metal1                      "metal"           14  )
  ( Via1                        "cut"             15  )
  ( Metal2                      "metal"           16  )
  ( Via2                        "cut"             17  )
  ( Metal3                      "metal"           18  )
  ( Via3                        "cut"             19  )
  ( Metal4                      "metal"           20  )
  ( Via4                        "cut"             21  )
  ( Metal5                      "metal"           22  )
  ( Via5                        "cut"             23  )
  ( Metal6                      "metal"           24  )
  ( Via6                        "cut"             25  )
  ( Metal7                      "metal"           26  )
  ( Via7                        "cut"             27  )
  ( Metal8                      "metal"           28  )
  ( Via8                        "cut"             29  )
  ( Metal9                      "metal"           30  )
  ( Bondpad                     "other"           31  )
 ) ;layerFunctions

) ;layerRules
;********************************
; PHYSICAL RULES
;********************************
physicalRules(

 spacingRules(
 ;( rule                	layer1    	layer2    	value    )
 ;( ----                	------    	------    	-----    )
  ( minWidth            	"Nwell"			0.6	 )
  ( minNotch            	"Nwell"			0.6	 )
  ( minSpacing          	"Nwell"			0.6	 )
  ( minWidth            	"Oxide"			0.1	 )
  ( minNotch            	"Oxide"			0.15	 )
  ( minSpacing          	"Oxide"			0.15	 )
  ( minWidth            	"Oxide_thk"			0.7	 )
  ( minNotch            	"Oxide_thk"			0.35	 )
  ( minSpacing          	"Oxide_thk"			0.35	 )
  ( minWidth            	"Poly"			0.1	 )
  ( minNotch            	"Poly"			0.12	 )
  ( minSpacing          	"Poly"			0.12	 )
  ( minWidth            	"Pimp"			0.24	 )
  ( minNotch            	"Pimp"			0.24	 )
  ( minSpacing          	"Pimp"			0.24	 )
  ( minWidth            	"Nimp"			0.24	 )
  ( minNotch            	"Nimp"			0.24	 )
  ( minSpacing          	"Nimp"			0.24	 )
  ( minWidth            	"Nzvt"			0.7	 )
  ( minNotch            	"Nzvt"			0.6	 )
  ( minSpacing          	"Nzvt"			0.6	 )
  ( minWidth            	"SiProt"			0.44	 )
  ( minNotch            	"SiProt"			0.44	 )
  ( minSpacing          	"SiProt"			0.44	 )
  ( minWidth            	"Cont"			0.12	 )
  ( minNotch            	"Cont"			0.14	 )
  ( minSpacing          	"Cont"			0.14	 )
  ( minNotch            	"Metal1"			0.12	 )
  ( minSpacing          	"Metal1"			0.12	 )
  ( minWidth            	"Via1"			0.14	 )
  ( minNotch            	"Via1"			0.15	 )
  ( minNotch            	"Metal2"			0.14	 )
  ( minSpacing          	"Metal2"			0.14	 )
  ( minWidth            	"Via2"			0.14	 )
  ( minNotch            	"Via2"			0.15	 )
  ( minNotch            	"Metal3"			0.14	 )
  ( minSpacing          	"Metal3"			0.14	 )
  ( minWidth            	"Via3"			0.14	 )
  ( minNotch            	"Via3"			0.15	 )
  ( minNotch            	"Metal4"			0.14	 )
  ( minSpacing          	"Metal4"			0.14	 )
  ( minWidth            	"Via4"			0.14	 )
  ( minNotch            	"Via4"			0.15	 )
  ( minNotch            	"Metal5"			0.14	 )
  ( minSpacing          	"Metal5"			0.14	 )
  ( minWidth            	"Via5"			0.14	 )
  ( minNotch            	"Via5"			0.15	 )
  ( minNotch            	"Metal6"			0.14	 )
  ( minSpacing          	"Metal6"			0.14	 )
  ( minWidth            	"Via6"			0.14	 )
  ( minNotch            	"Via6"			0.15	 )
  ( minNotch            	"Metal7"			0.14	 )
  ( minSpacing          	"Metal7"			0.14	 )
  ( minWidth            	"Via7"			0.36	 )
  ( minNotch            	"Via7"			0.36	 )
  ( minNotch            	"Metal8"			0.4	 )
  ( minSpacing          	"Metal8"			0.4	 )
  ( minWidth            	"Via8"			0.36	 )
  ( minNotch            	"Via8"			0.36	 )
  ( minNotch            	"Metal9"			0.4	 )
  ( minSpacing          	"Metal9"			0.4	 )
  ( minWidth            	"Nburied"			3.2	 )
  ( minNotch            	"Nburied"			5.0	 )
  ( minSpacing          	"Nburied"			5.0	 )
  ( minWidth            	("Metal1" "slot")			2.0	 )
  ( minNotch            	("Metal1" "slot")			0.12	 )
  ( minSpacing          	("Metal1" "slot")			0.12	 )
  ( minWidth            	("Metal2" "slot")			2.0	 )
  ( minNotch            	("Metal2" "slot")			0.14	 )
  ( minSpacing          	("Metal2" "slot")			0.14	 )
  ( minWidth            	("Metal3" "slot")			2.0	 )
  ( minNotch            	("Metal3" "slot")			0.14	 )
  ( minSpacing          	("Metal3" "slot")			0.14	 )
  ( minWidth            	("Metal4" "slot")			2.0	 )
  ( minNotch            	("Metal4" "slot")			0.14	 )
  ( minSpacing          	("Metal4" "slot")			0.14	 )
  ( minWidth            	("Metal5" "slot")			2.0	 )
  ( minNotch            	("Metal5" "slot")			0.14	 )
  ( minSpacing          	("Metal5" "slot")			0.14	 )
  ( minWidth            	("Metal6" "slot")			2.0	 )
  ( minNotch            	("Metal6" "slot")			0.14	 )
  ( minSpacing          	("Metal6" "slot")			0.14	 )
  ( minWidth            	("Metal7" "slot")			2.0	 )
  ( minNotch            	("Metal7" "slot")			0.14	 )
  ( minSpacing          	("Metal7" "slot")			0.14	 )
  ( minWidth            	("Metal8" "slot")			2.0	 )
  ( minNotch            	("Metal8" "slot")			0.44	 )
  ( minSpacing          	("Metal8" "slot")			0.44	 )
  ( minWidth            	("Metal9" "slot")			2.0	 )
  ( minNotch            	("Metal9" "slot")			0.44	 )
  ( minSpacing          	("Metal9" "slot")			0.44	 )
  ( minNotch            	"Bondpad"			5.0	 )
  ( minSpacing          	"Bondpad"			5.0	 )
  ( minWidth            	"Metal1"			0.12	 )
  ( minEnclosedArea     	"Metal1"			0.05	 )
  ( minArea             	"Metal1"			0.07	 )
  ( maxWidth            	"Metal1"			12.0	 )
  ( minimumDensity      	"Metal1"			20.0	 )
  ( maximumDensity      	"Metal1"			65.0	 )
  ( densityCheckWindow  	"Metal1"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal1"			60.0	 )
  ( minimumCut          	"Metal1"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Via1"			0.15	 )
  ( viaSpacing          	"Via1"			(3 0.21 0.2)	 )
  ( minWidth            	"Metal2"			0.14	 )
  ( minEnclosedArea     	"Metal2"			0.07	 )
  ( minArea             	"Metal2"			0.08	 )
  ( maxWidth            	"Metal2"			12.0	 )
  ( minimumDensity      	"Metal2"			20.0	 )
  ( maximumDensity      	"Metal2"			65.0	 )
  ( densityCheckWindow  	"Metal2"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal2"			60.0	 )
  ( minimumCut          	"Metal2"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Via2"			0.15	 )
  ( viaSpacing          	"Via2"			(3 0.21 0.2)	 )
  ( minWidth            	"Metal3"			0.14	 )
  ( minEnclosedArea     	"Metal3"			0.07	 )
  ( minArea             	"Metal3"			0.08	 )
  ( maxWidth            	"Metal3"			12.0	 )
  ( minimumDensity      	"Metal3"			20.0	 )
  ( maximumDensity      	"Metal3"			65.0	 )
  ( densityCheckWindow  	"Metal3"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal3"			60.0	 )
  ( minimumCut          	"Metal3"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Via3"			0.15	 )
  ( viaSpacing          	"Via3"			(3 0.21 0.2)	 )
  ( minWidth            	"Metal4"			0.14	 )
  ( minEnclosedArea     	"Metal4"			0.07	 )
  ( minArea             	"Metal4"			0.08	 )
  ( maxWidth            	"Metal4"			12.0	 )
  ( minimumDensity      	"Metal4"			20.0	 )
  ( maximumDensity      	"Metal4"			65.0	 )
  ( densityCheckWindow  	"Metal4"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal4"			60.0	 )
  ( minimumCut          	"Metal4"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Via4"			0.15	 )
  ( viaSpacing          	"Via4"			(3 0.21 0.2)	 )
  ( minWidth            	"Metal5"			0.14	 )
  ( minEnclosedArea     	"Metal5"			0.07	 )
  ( minArea             	"Metal5"			0.08	 )
  ( maxWidth            	"Metal5"			12.0	 )
  ( minimumDensity      	"Metal5"			20.0	 )
  ( maximumDensity      	"Metal5"			65.0	 )
  ( densityCheckWindow  	"Metal5"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal5"			60.0	 )
  ( minimumCut          	"Metal5"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Via5"			0.15	 )
  ( viaSpacing          	"Via5"			(3 0.21 0.2)	 )
  ( minWidth            	"Metal6"			0.14	 )
  ( minEnclosedArea     	"Metal6"			0.07	 )
  ( minArea             	"Metal6"			0.08	 )
  ( maxWidth            	"Metal6"			12.0	 )
  ( minimumDensity      	"Metal6"			20.0	 )
  ( maximumDensity      	"Metal6"			65.0	 )
  ( densityCheckWindow  	"Metal6"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal6"			60.0	 )
  ( minimumCut          	"Metal6"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Via6"			0.15	 )
  ( viaSpacing          	"Via6"			(3 0.21 0.2)	 )
  ( minWidth            	"Metal7"			0.14	 )
  ( minEnclosedArea     	"Metal7"			0.07	 )
  ( minArea             	"Metal7"			0.08	 )
  ( maxWidth            	"Metal7"			12.0	 )
  ( minimumDensity      	"Metal7"			20.0	 )
  ( maximumDensity      	"Metal7"			65.0	 )
  ( densityCheckWindow  	"Metal7"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal7"			60.0	 )
  ( minimumCut          	"Metal7"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Via7"			0.36	 )
  ( viaSpacing          	"Via7"			(3 0.5 0.54)	 )
  ( minWidth            	"Metal8"			0.44	 )
  ( minEnclosedArea     	"Metal8"			0.5	 )
  ( minArea             	"Metal8"			0.2 	 )
  ( maxWidth            	"Metal8"			12.0	 )
  ( minimumDensity      	"Metal8"			20.0	 )
  ( maximumDensity      	"Metal8"			65.0	 )
  ( densityCheckWindow  	"Metal8"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal8"			60.0	 )
  ( minimumCut          	"Metal8"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Via8"			0.36	 )
  ( viaSpacing          	"Via8"			(3 0.5 0.54)	 )
  ( minWidth            	"Metal9"			0.44	 )
  ( minEnclosedArea     	"Metal9"			0.5	 )
  ( minArea             	"Metal9"			0.2 	 )
  ( maxWidth            	"Metal9"			12.0	 )
  ( minimumDensity      	"Metal9"			20.0	 )
  ( maximumDensity      	"Metal9"			65.0	 )
  ( densityCheckWindow  	"Metal9"			("120.0000 120.0000")	 )
  ( densityCheckStep    	"Metal9"			60.0	 )
  ( minimumCut          	"Metal9"			("2.0000 WIDTH         2.0000")	 )
  ( minSpacing          	"Nwell"		"Oxide"		0.3	 )
  ( minSpacing          	"Nwell"		"Nzvt"		1.2	 )
  ( minSpacing          	"Nwell"		"SiProt"		0.32	 )
  ( minSpacing          	"Nwell"		"Nburied"		4.4	 )
  ( minSpacing          	"Oxide"		"Oxide_thk"		1.8	 )
  ( minSpacing          	"Oxide"		"Poly"		0.1	 )
  ( minSpacing          	"Oxide"		"Pimp"		0.02	 )
  ( minSpacing          	"Oxide"		"Nimp"		0.02	 )
  ( minSpacing          	"Oxide"		"Nzvt"		0.4	 )
  ( minSpacing          	"Oxide"		"SiProt"		0.24	 )
  ( minSpacing          	"Oxide"		"Cont"		0.12	 )
  ( minSpacing          	"Oxide"		"Nburied"		2.2	 )
  ( minSpacing          	"Oxide_thk"		"Poly"		0.34	 )
  ( minSpacing          	"Poly"		"Pimp"		0.18	 )
  ( minSpacing          	"Poly"		"Nimp"		0.18	 )
  ( minSpacing          	"Poly"		"Nzvt"		0.3	 )
  ( minSpacing          	"Poly"		"SiProt"		0.35	 )
  ( minSpacing          	"Poly"		"Cont"		0.1	 )
  ( minSpacing          	"Pimp"		"Nimp"		0.18	 )
  ( minSpacing          	"SiProt"		"Cont"		0.24	 )
  ( minSpacing          	"Cont"		"Resdum"		0.2	 )
 ) ;spacingRules

 mfgGridResolution(
      ( 0.005000 )
 ) ;mfgGridResolution

 orderedSpacingRules(
 ;( rule                	layer1    	layer2    	value    )
 ;( ----                	------    	------    	-----    )
  ( minEnclosure        	"Metal1"		"Via1"		0.005	 )
  ( minEnclosure        	"Metal2"		"Via1"		0.005	 )
  ( minEnclosure        	"Metal2"		"Via2"		0.005	 )
  ( minEnclosure        	"Metal3"		"Via2"		0.005	 )
  ( minEnclosure        	"Metal3"		"Via3"		0.005	 )
  ( minEnclosure        	"Metal4"		"Via3"		0.005	 )
  ( minEnclosure        	"Metal4"		"Via4"		0.005	 )
  ( minEnclosure        	"Metal5"		"Via4"		0.005	 )
  ( minEnclosure        	"Metal5"		"Via5"		0.005	 )
  ( minEnclosure        	"Metal6"		"Via5"		0.005	 )
  ( minEnclosure        	"Metal6"		"Via6"		0.005	 )
  ( minEnclosure        	"Metal7"		"Via6"		0.005	 )
  ( minEnclosure        	"Metal7"		"Via7"		0.03	 )
  ( minEnclosure        	"Metal8"		"Via7"		0.05	 )
  ( minEnclosure        	"Metal8"		"Via8"		0.03	 )
  ( minEnclosure        	"Metal9"		"Via8"		0.05	 )
  ( minEnclosure          "Metal1"    "Cont"    0.00   )
  ( minEnclosure          "Oxide"     "Poly"    0.20   )
  ( minEnclosure          "Nimp"      "Oxide"   0.14   )
  ( minEnclosure          "Nimp"      "Poly"    0.18   )
  ( minEnclosure          "Pimp"      "Poly"    0.12   )
  ( minEnclosure          "Pimp"      "Oxide"   0.18   )
  ( minEnclosure          "Nwell"     "Oxide"   0.14   )
 ) ;orderedSpacingRules

 tableSpacingRules(
 ;( rule                	layer1    	[layer2]  
 ;  (index1Definitions     [index2Defintions])
 ;  (table) )
 ;( ----------------------------------------------------------------------)
  ( "viaSpacing"	"Via1"
    ("adjacentVias" (3 0) nil)
    (
      (3 "<")	0.15	(3 ">=")	0.2
    )
  )
  ( "viaSpacing"	"Via2"
    ("adjacentVias" (3 0) nil)
    (
      (3 "<")	0.15	(3 ">=")	0.2
    )
  )
  ( "viaSpacing"	"Via3"
    ("adjacentVias" (3 0) nil)
    (
      (3 "<")	0.15	(3 ">=")	0.2
    )
  )
  ( "viaSpacing"	"Via4"
    ("adjacentVias" (3 0) nil)
    (
      (3 "<")	0.15	(3 ">=")	0.2
    )
  )
  ( "viaSpacing"	"Via5"
    ("adjacentVias" (3 0) nil)
    (
      (3 "<")	0.15	(3 ">=")	0.2
    )
  )
  ( "viaSpacing"	"Via6"
    ("adjacentVias" (3 0) nil)
    (
      (3 "<")	0.15	(3 ">=")	0.2
    )
  )
  ( "viaSpacing"	"Via7"
    ("adjacentVias" (3 0) nil)
    (
      (3 "<")	0.36	(3 ">=")	0.54
    )
  )
  ( "viaSpacing"	"Via8"
    ("adjacentVias" (3 0) nil)
    (
      (3 "<")	0.36	(3 ">=")	0.54
    )
  )
  ( "minSpacing"	"Metal1"
    ("width" (0.0 0.18 1.5 3.0 4.5 7.5) nil "length" (0.0 0.56 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.18 ">") (0.56 ">"))	0.18	((0.0 ">=") (0.0 ">="))	0.12
    )
  )
  ( "minSpacing"	"Metal2"
    ("width" (0.0 0.2 1.5 3.0 4.5 7.5) nil "length" (0.0 0.56 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.2 ">") (0.56 ">"))	0.2	((0.0 ">=") (0.0 ">="))	0.14
    )
  )
  ( "minSpacing"	"Metal3"
    ("width" (0.0 0.2 1.5 3.0 4.5 7.5) nil "length" (0.0 0.56 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.2 ">") (0.56 ">"))	0.2	((0.0 ">=") (0.0 ">="))	0.14
    )
  )
  ( "minSpacing"	"Metal4"
    ("width" (0.0 0.2 1.5 3.0 4.5 7.5) nil "length" (0.0 0.56 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.2 ">") (0.56 ">"))	0.2	((0.0 ">=") (0.0 ">="))	0.14
    )
  )
  ( "minSpacing"	"Metal5"
    ("width" (0.0 0.2 1.5 3.0 4.5 7.5) nil "length" (0.0 0.56 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.2 ">") (0.56 ">"))	0.2	((0.0 ">=") (0.0 ">="))	0.14
    )
  )
  ( "minSpacing"	"Metal6"
    ("width" (0.0 0.2 1.5 3.0 4.5 7.5) nil "length" (0.0 0.56 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.2 ">") (0.56 ">"))	0.2	((0.0 ">=") (0.0 ">="))	0.14
    )
  )
  ( "minSpacing"	"Metal7"
    ("width" (0.0 0.2 1.5 3.0 4.5 7.5) nil "length" (0.0 0.56 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.2 ">") (0.56 ">"))	0.2	((0.0 ">=") (0.0 ">="))	0.14
    )
  )
  ( "minSpacing"	"Metal8"
    ("width" (0.0 1.5 3.0 4.5 7.5) nil "length" (0.0 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.0 ">=") (0.0 ">="))	0.4
    )
  )
  ( "minSpacing"	"Metal9"
    ("width" (0.0 1.5 3.0 4.5 7.5) nil "length" (0.0 1.5 3.0 4.5 7.5) nil)
    (
      ((7.5 ">") (7.5 ">"))	2.5	((4.5 ">") (4.5 ">"))	1.5
      ((3.0 ">") (3.0 ">"))	0.9	((1.5 ">") (1.5 ">"))	0.5
      ((0.0 ">=") (0.0 ">="))	0.4
    )
  )
 ) ;tableSpacingRules
;********************************
; ELECTRICAL RULES
;********************************
electricalRules(

 characterizationRules(
 ;( rule                	layer1    	layer2    	value    )
 ;( ----                	------    	------    	-----    )
  ( contactRes          	"Poly"			10	 )
  ( contactRes          	"Oxide"			0	 )
  ( contactRes          	"Metal1"			1	 )
  ( contactRes          	"Via1"			1.4	 )
  ( contactRes          	"Via2"			1.4	 )
  ( contactRes          	"Via3"			1.4	 )
  ( contactRes          	"Via4"			1.4	 )
  ( contactRes          	"Via5"			1.4	 )
  ( contactRes          	"Via6"			1.4	 )
  ( contactRes          	"Via7"			0.35	 )
  ( contactRes          	"Via8"			0.35	 )
  ( sheetRes            	"Nwell"			400.0	 )
  ( sheetRes            	"Poly"			100.0	 )
  ( sheetRes            	"Metal1"			0.08	 )
  ( areaCap             	"Metal1"			0.0002	 )
  ( edgeCap             	"Metal1"			0.0002	 )
  ( thickness           	"Metal1"			0.3	 )
  ( defaultAntennaRule  	"Metal1"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 45050) (1.0 45500)) _NA_ _NA_ _NA_ _NA_)	 )
  ( defaultAntennaRule  	"Via1"			(25.0 _NA_ ((0 25) (0.099 25) (0.1 1025) (1.0 1250)) _NA_ _NA_ _NA_ _NA_ _NA_ _NA_ _NA_)	 )
  ( sheetRes            	"Metal2"			0.06	 )
  ( areaCap             	"Metal2"			0.0002	 )
  ( edgeCap             	"Metal2"			0.0002	 )
  ( thickness           	"Metal2"			0.36	 )
  ( defaultAntennaRule  	"Metal2"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 45050) (1.0 45500)) _NA_ _NA_ _NA_ _NA_)	 )
  ( defaultAntennaRule  	"Via2"			(25.0 _NA_ ((0 25) (0.099 25) (0.1 1025) (1.0 1250)) _NA_ _NA_ _NA_ _NA_ _NA_ _NA_ _NA_)	 )
  ( sheetRes            	"Metal3"			0.06	 )
  ( areaCap             	"Metal3"			0.0002	 )
  ( edgeCap             	"Metal3"			0.0002	 )
  ( thickness           	"Metal3"			0.36	 )
  ( defaultAntennaRule  	"Metal3"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 45050) (1.0 45500)) _NA_ _NA_ _NA_ _NA_)	 )
  ( defaultAntennaRule  	"Via3"			(25.0 _NA_ ((0 25) (0.099 25) (0.1 1025) (1.0 1250)) _NA_ _NA_ _NA_ _NA_ _NA_ _NA_ _NA_)	 )
  ( sheetRes            	"Metal4"			0.06	 )
  ( areaCap             	"Metal4"			0.0002	 )
  ( edgeCap             	"Metal4"			0.0002	 )
  ( thickness           	"Metal4"			0.36	 )
  ( defaultAntennaRule  	"Metal4"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 45050) (1.0 45500)) _NA_ _NA_ _NA_ _NA_)	 )
  ( defaultAntennaRule  	"Via4"			(25.0 _NA_ ((0 25) (0.099 25) (0.1 1025) (1.0 1250)) _NA_ _NA_ _NA_ _NA_ _NA_ _NA_ _NA_)	 )
  ( sheetRes            	"Metal5"			0.06	 )
  ( areaCap             	"Metal5"			0.0002	 )
  ( edgeCap             	"Metal5"			0.0002	 )
  ( thickness           	"Metal5"			0.36	 )
  ( defaultAntennaRule  	"Metal5"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 45050) (1.0 45500)) _NA_ _NA_ _NA_ _NA_)	 )
  ( defaultAntennaRule  	"Via5"			(25.0 _NA_ ((0 25) (0.099 25) (0.1 1025) (1.0 1250)) _NA_ _NA_ _NA_ _NA_ _NA_ _NA_ _NA_)	 )
  ( sheetRes            	"Metal6"			0.06	 )
  ( areaCap             	"Metal6"			0.0002	 )
  ( edgeCap             	"Metal6"			0.0002	 )
  ( thickness           	"Metal6"			0.36	 )
  ( defaultAntennaRule  	"Metal6"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 45050) (1.0 45500)) _NA_ _NA_ _NA_ _NA_)	 )
  ( defaultAntennaRule  	"Via6"			(25.0 _NA_ ((0 25) (0.099 25) (0.1 1025) (1.0 1250)) _NA_ _NA_ _NA_ _NA_ _NA_ _NA_ _NA_)	 )
  ( sheetRes            	"Metal7"			0.06	 )
  ( areaCap             	"Metal7"			0.0002	 )
  ( edgeCap             	"Metal7"			0.0002	 )
  ( thickness           	"Metal7"			0.36	 )
  ( defaultAntennaRule  	"Metal7"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 45050) (1.0 45500)) _NA_ _NA_ _NA_ _NA_)	 )
  ( defaultAntennaRule  	"Via7"			(25.0 _NA_ ((0 25) (0.099 25) (0.1 1025) (1.0 1250)) _NA_ _NA_ _NA_ _NA_ _NA_ _NA_ _NA_)	 )
  ( sheetRes            	"Metal8"			0.02	 )
  ( areaCap             	"Metal8"			0.0002	 )
  ( edgeCap             	"Metal8"			0.0002	 )
  ( thickness           	"Metal8"			1.0	 )
  ( defaultAntennaRule  	"Metal8"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 45050) (1.0 45500)) _NA_ _NA_ _NA_ _NA_)	 )
  ( defaultAntennaRule  	"Via8"			(25.0 _NA_ ((0 25) (0.099 25) (0.1 1025) (1.0 1250)) _NA_ _NA_ _NA_ _NA_ _NA_ _NA_ _NA_)	 )
  ( sheetRes            	"Metal9"			0.02	 )
  ( areaCap             	"Metal9"			0.0002	 )
  ( edgeCap             	"Metal9"			0.0002	 )
  ( thickness           	"Metal9"			1.0	 )
  ( defaultAntennaRule  	"Metal9"			(475.0 _NA_ _NA_ _NA_ 1200.0 ((0 1200) (0.099 1200) (0.1 55750) (1.0 62500)) _NA_ _NA_ _NA_ _NA_)	 )
 ) ;characterizationRules

) ;electricalRules
;********************************
; DEVICES
;********************************
devices(
tcCreateCDSDeviceClass()

;
; no syEnhancement devices
;

;
; no syDepletion devices
;

symContactDevice(
; (name viaLayer viaPurpose layer1 purpose1 layer2 purpose2
;  w l (row column xPitch yPitch xBias yBias) encByLayer1 encByLayer2 legalRegion)

  (M1_PO Cont drawing Poly drawing Metal1 drawing
  0.12 0.12 (1 1 0.28 0.28 center center) 0.06 0.06 _NA_)

  (M1_NWELL Cont drawing Oxide drawing (Nimp drawing 0.08) Metal1 drawing (Nwell drawing 0.18)
  0.12 0.12 (1 1 0.28 0.28 center center) 0.07 0.06 _NA_)

  (M1_NIMP Cont drawing Oxide drawing (Nimp drawing 0.08) Metal1 drawing
  0.12 0.12 (1 1 0.28 0.28 center center) 0.07 0.06 _NA_)

  (M1_PIMP Cont drawing Oxide drawing (Pimp drawing 0.08) Metal1 drawing
  0.12 0.12 (1 1 0.28 0.28 center center) 0.1 0.06 _NA_)

  (M1_PSUB Cont drawing Oxide drawing (Pimp drawing 0.08) Metal1 drawing
  0.12 0.12 (1 1 0.28 0.28 center center) 0.1 0.06 _NA_)

  (M2_M1 Via1 drawing Metal1 drawing Metal2 drawing
  0.14 0.14 (1 1 0.34 0.34 center center) 0.06 0.06 _NA_)

  (M3_M2 Via2 drawing Metal2 drawing Metal3 drawing
  0.14 0.14 (1 1 0.34 0.34 center center) 0.06 0.06 _NA_)

  (M4_M3 Via3 drawing Metal3 drawing Metal4 drawing
  0.14 0.14 (1 1 0.34 0.34 center center) 0.06 0.06 _NA_)

  (M5_M4 Via4 drawing Metal4 drawing Metal5 drawing
  0.14 0.14 (1 1 0.34 0.34 center center) 0.06 0.06 _NA_)

  (M6_M5 Via5 drawing Metal5 drawing Metal6 drawing
  0.14 0.14 (1 1 0.34 0.34 center center) 0.06 0.06 _NA_)

  (M7_M6 Via6 drawing Metal6 drawing Metal7 drawing
  0.14 0.14 (1 1 0.34 0.34 center center) 0.06 0.06 _NA_)

  (M8_M7 Via7 drawing Metal7 drawing Metal8 drawing
  0.36 0.36 (1 1 0.72 0.72 center center) 0.08 0.1 _NA_)

  (M9_M8 Via8 drawing Metal8 drawing Metal9 drawing
  0.36 0.36 (1 1 0.72 0.72 center center) 0.08 0.1 _NA_)
)

tfcDefineDeviceProp(
; (viewName        deviceName        propName          propValue)
  (symbolic        M2_M1             res               1.400000)
  (symbolic        M3_M2             res               1.400000)
  (symbolic        M4_M3             res               1.400000)
  (symbolic        M5_M4             res               1.400000)
  (symbolic        M6_M5             res               1.400000)
  (symbolic        M7_M6             res               1.400000)
  (symbolic        M8_M7             res               0.350000)
  (symbolic        M9_M8             res               0.350000)
)

cdsViaDevice(
; (name cutLayer cutPurpose layer1 purpose1 layer2 purpose2
;  row column origin stackedVias cutLayerW cutLayerL xCutSpacing yCutSpacing
;  layer1XDirOverride layer1YDirOverride layer2XDirOverride layer2YDirOverride
;  layer1Dir layer2Dir
;  layer1XDefOverride layer1YDefOverride layer2XDefOverride layer2YDefOverride
;  implantLayer1 implantLayer2 diffSpacing abutClass)

  (M1_POLYc Cont drawing Poly drawing Metal1 drawing
  1 1 centerCenter t _def_ _def_ 0.16 0.16
  0.04 0.06 0 0.06
  "Y" "Y"
  _def_ _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M1_DIFFc Cont drawing Oxide drawing Metal1 drawing
  1 1 centerCenter t _def_ _def_ 0.16 0.16
  0.1 0.1 0 0.06
  "Y" "Y"
  _def_ _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M2_M1c Via1 drawing Metal1 drawing Metal2 drawing
  1 1 centerCenter t _def_ _def_ 0.2 0.2
  _def_ 0.06 _def_ 0.06
  "Y" "Y"
  0.005 _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M3_M2c Via2 drawing Metal2 drawing Metal3 drawing
  1 1 centerCenter t _def_ _def_ 0.2 0.2
  _def_ 0.06 _def_ 0.06
  "Y" "Y"
  0.005 _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M4_M3c Via3 drawing Metal3 drawing Metal4 drawing
  1 1 centerCenter t _def_ _def_ 0.2 0.2
  _def_ 0.06 _def_ 0.06
  "Y" "Y"
  0.005 _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M5_M4c Via4 drawing Metal4 drawing Metal5 drawing
  1 1 centerCenter t _def_ _def_ 0.2 0.2
  _def_ 0.06 _def_ 0.06
  "Y" "Y"
  0.005 _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M6_M5c Via5 drawing Metal5 drawing Metal6 drawing
  1 1 centerCenter t _def_ _def_ 0.2 0.2
  _def_ 0.06 _def_ 0.06
  "Y" "Y"
  0.005 _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M7_M6c Via6 drawing Metal6 drawing Metal7 drawing
  1 1 centerCenter t _def_ _def_ 0.2 0.2
  _def_ 0.06 _def_ 0.06
  "Y" "Y"
  0.005 _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M8_M7c Via7 drawing Metal7 drawing Metal8 drawing
  1 1 centerCenter t _def_ _def_ _def_ _def_
  _def_ 0.08 _def_ 0.1
  "Y" "Y"
  0.03 _def_ _def_ _def_
  nil
  nil
  _def_ "")

  (M9_M8c Via8 drawing Metal8 drawing Metal9 drawing
  1 1 centerCenter t _def_ _def_ _def_ _def_
  0.05 0.08 _def_ 0.1
  "Y" "Y"
  0.03 _def_ _def_ _def_
  nil
  nil
  _def_ "")

)

;
; no cdsMos devices
;

symPinDevice(
; (name maskable layer1 purpose1 w1 layer2 purpose2 w2 legalRegion)
  (poly1_T t Poly drawing 0.12 _NA_ _NA_ _NA_ _NA_)
  (nwell_T t Nwell drawing 0.6 _NA_ _NA_ _NA_ _NA_)
  (m1_T t Metal1 drawing 0.12 _NA_ _NA_ _NA_ _NA_)
  (m2_T t Metal2 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (m3_T t Metal3 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (m4_T t Metal4 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (m5_T t Metal5 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (m6_T t Metal6 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (m7_T t Metal7 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (m8_T t Metal8 drawing 0.44 _NA_ _NA_ _NA_ _NA_)
  (m9_T t Metal9 drawing 0.44 _NA_ _NA_ _NA_ _NA_)
  (Metal1_T nil Metal1 drawing 0.12 _NA_ _NA_ _NA_ _NA_)
  (Metal2_T nil Metal2 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (Metal3_T nil Metal3 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (Metal4_T nil Metal4 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (Metal5_T nil Metal5 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (Metal6_T nil Metal6 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (Metal7_T nil Metal7 drawing 0.14 _NA_ _NA_ _NA_ _NA_)
  (Metal8_T nil Metal8 drawing 0.44 _NA_ _NA_ _NA_ _NA_)
  (Metal9_T nil Metal9 drawing 0.44 _NA_ _NA_ _NA_ _NA_)
)

symRectPinDevice(
; (name maskable layer1 purpose1 w l legalRegion)
  (Metal1_Rect_T nil Metal1 drawing 0.12 0.12 _NA_)
  (Metal2_Rect_T nil Metal2 drawing 0.14 0.14 _NA_)
  (Metal3_Rect_T nil Metal3 drawing 0.14 0.14 _NA_)
  (Metal4_Rect_T nil Metal4 drawing 0.14 0.14 _NA_)
  (Metal5_Rect_T nil Metal5 drawing 0.14 0.14 _NA_)
  (Metal6_Rect_T nil Metal6 drawing 0.14 0.14 _NA_)
  (Metal7_Rect_T nil Metal7 drawing 0.14 0.14 _NA_)
  (Metal8_Rect_T nil Metal8 drawing 0.44 0.44 _NA_)
  (Metal9_Rect_T nil Metal9 drawing 0.44 0.44 _NA_)
)

ruleContactDevice(
; ( viaName (layer1 purpose1 layer1BBox1 [layer1BBox2 ...])
;           (viaLayer viaPurpose viaLayerBBox1 [viaLayerBBox2 ...])
;           (layer2 purpose2 layer2BBox1 [layer2BBox2 ...])
; )
  ( ruleVia
    ( Metal1 drawing
       ( -1.500000 -0.900000 1.500000 0.900000 )
    )
    ( Via1 drawing
       ( -0.900000 -0.300000 -0.300000 0.300000 )
       ( 0.300000 -0.300000 0.900000 0.300000 )
    )
    ( Metal2 drawing
       ( -1.500000 -0.900000 1.500000 0.900000 )
    )
  )
)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Opus Symbolic Device Class Definition
;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;
; no other device classes
;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Opus Symbolic Device Declaration
;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;
; no other devices
;
) ;devices

;********************************
; COMPACTOR RULES
;********************************
compactorRules(

 compactorLayers(
 ;( layer                       usage      )
 ;( -----                       -----      )
  ( Metal1                      "conduction" )
  ( Via1                        "via"      )
  ( Metal2                      "conduction" )
  ( Via2                        "via"      )
  ( Metal3                      "conduction" )
  ( Via3                        "via"      )
  ( Metal4                      "conduction" )
  ( Via4                        "via"      )
  ( Metal5                      "conduction" )
  ( Via5                        "via"      )
  ( Metal6                      "conduction" )
  ( Via6                        "via"      )
  ( Metal7                      "conduction" )
  ( Via7                        "via"      )
  ( Metal8                      "conduction" )
  ( Via8                        "via"      )
  ( Metal9                      "conduction" )
  ( Cont                        "via"      )
  ( Poly                        "conduction" )
  ( Nwell                       "well"     )
  ( Oxide                       "diffusion" )
  ( Nimp                        "implant"  )
  ( Pimp                        "implant"  )
 ) ;compactorLayers

) ;compactorRules

;********************************
; LX RULES
;********************************
lxRules(

 lxExtractLayers(
 ;( list of layers or layer/purpose pairs  )
 ;( -------------------------------------  )
  ( Metal1    	Via1      	Metal2    	Via2      	Metal3    	Cont      	Poly      	Nwell     	  	Oxide     	
    Via3      	Metal4    	Via4      	Metal5    	Via5      	Metal6    	Via6         Metal7           Via7 
    Metal8      Via8          Metal9      Bondpad    )
 ) ;lxExtractLayers

 lxNoOverlapLayers(
 ;( forbidden overlaps in LX )
 ;( ------------------------ )
  ( Poly      	Oxide      )
  ( Poly      	Resdum     )
 ) ;lxNoOverlapLayers

 lxMPPTemplates(
 ;( name [masterPath] [offsetSubpaths] [encSubPaths] [subRects] )
 ;
 ;  masterPath:
 ;  (layer [width] [choppable] [endType] [beginExt] [endExt] [justify] [offset]
 ;  [connectivity])
 ;
 ;  offsetSubpaths:
 ;  (layer [width] [choppable] [separation] [justification] [begOffset] [endOffset]
 ;  [connectivity])
 ;
 ;  encSubPaths:
 ;  (layer [enclosure] [choppable] [separation] [begOffset] [endOffset]
 ;  [connectivity])
 ;
 ;  subRects:
 ;  (layer [width] [length] [choppable] [separation] [justification] [space] [begOffset] [endOffset] [gap] 
 ;  [connectivity])
 ;
 ;  connectivity:
 ;  ([I/O type] [pin] [accDir] [dispPinName] [height] [ layer]
 ;   [layer] [justification] [font] [textOptions] [orientation]
 ;   [refHandle] [offset])
 ;
 ;( --------------------------------------------------------------------- )
    ( "N-Tap"
      ;; master path:
      (
	 ("Oxide" "drawing")		;; layer
	 techParam("CONTW1")+2*techParam("CONTE1")         ;; width
	 t				;; choppable
      )
      
      ;; offset subpaths
      (
	  (
	    ("Metal1" "drawing")	;; layer-purpose pair
	    techParam("CONTW1")+2*techParam("METAL1E2")   ;; width
	    t			    ;; choppable
	    0				;; separation
	    "center"     ;; justification
	    -(techParam("CONTE1")-techParam("METAL1E2"))  ;; beginOffset
	    -(techParam("CONTE1")-techParam("METAL1E2"))	;; endOffset
	  )
	  (
	    ("Nwell" "drawing")	;; layer-purpose pair
	    techParam("NWW1")   ;; width
	    t			    ;; choppable
	    0				;; separation
	    "center"     ;; justification
	    0.18 ;;techParam("NWE1") ;; beginOffset
	    0.18 ;;techParam("NWE1")	;; endOffset
	  )
      )
      ;; enclosure subpath
      (
 	  (
	    ("Nimp" "drawing")		;; layer
	    -techParam("NIMPE2")   ;; enclosure
	    t				;; choppable
 	  )
      )
   
      ;; subrectangles
      (
	 (
	    ("Cont" "drawing")    	;; layer
	    techParam("CONTW1")		;; width
	    techParam("CONTW1")		;; length
	    t				;; choppable
	    0				;; separation
	    "center"			;; justification
	    techParam("CONTSP1")		;; space
	    -techParam("CONTSP1")/2	;; beginOffset
	    -techParam("CONTSP1")/2	;; endOffset
	    "distribute"       		;; gap
	 )
      )
    ) ;; NWELL Tap


    ( "P-Tap"
      ;; master path:
      (
	  ("Oxide" "drawing")		;; layer
	  techParam("CONTW1")+2*techParam("CONTE1")         ;; width
	  t				;; choppable
      )
      
      ;; offset subpaths
      (
	  (
	  ("Metal1" "drawing")	;; layer-purpose pair
	  techParam("CONTW1")+2*techParam("METAL1E2")   ;; width
	  t			       	;; choppable
	  0				;; separation
	  "center"			;; justification
	  -(techParam("CONTE1")-techParam("METAL1E2"))  ;; beginOffset
	  -(techParam("CONTE1")-techParam("METAL1E2"))	;; endOffset
	   )
       )
       
       ;; enclosure subpath
      (
 	  (
 	  ("Pimp" "drawing")		;; layer
 	  -techParam("PIMPE2")   ;; enclosure
 	  t				;; choppable
 	  )
      )
  
      ;; subrectangles
      (
	  (
	    ("Cont" "drawing")    	;; layer
	    techParam("CONTW1")		;; width
	    techParam("CONTW1")		;; length
	    t				;; choppable
	    0				;; separation
	    "center"			;; justification
	    techParam("CONTSP1")		;; space
	    -techParam("CONTSP1")/2	;; beginOffset
	    -techParam("CONTSP1")/2	;; endOffset
	    "distribute"       		;; gap
	  )
      )
    ) ;; PWELL Tap
 
     ( "PO_M1"
      ;; master path:
      (
	 ("Poly" "drawing")		;; layer
	 techParam("CONTW1")            
	 +2*techParam("CONTE3")           ;; width
	  t				;; choppable
	 )
	 ;; offset subpaths
	 (
	    (
	       ("Metal1" "drawing")	;; layer-purpose pair
	       techParam("CONTW1")         
		+2*techParam("CONTE2")    ;; width
	       t			;; choppable
	       0			;; separation
	       "center"			;; justification
	       -(techParam("CONTE3")      
		 - techParam("METAL1E2")) ;; beginOffset 	    
	       -(techParam("CONTE3")      
		 - techParam("METAL1E2"))	;; endOffset 		
	    )
	 )
	 
	 ;; enclosure subpath
	 nil
	 
	 ;; subrectangles
	 (
	    (
	       ("Cont" "drawing")    	;; layer
	       techParam("CONTW1")	;; width
	       techParam("CONTW1")	;; length
	       t			;; choppable
	       0			;; separation
	       "center"			;; justification
	       techParam("CONTSP1")	;; space
	       -techParam("CONTE3")	;; beginOffset
	       -techParam("CONTE3")	;; endOffset
	       "distribute"       	;; gap
	    )
	 )
      ) ;; PO_M1

    ( "M1_M2"
      ;; master path:
      (
	  ("Metal1" "drawing")		;; layer
	   techParam("VIA1W1")            
	   +2*techParam("VIA1E1")         				;; width
	  t				;; choppable
      )
      ;; offset subpaths
      (
	  (
	    ("Metal2" "drawing")	;; layer-purpose pair
	    techParam("VIA1W1")            
	    +2*techParam("METAL2E1") 			;; width
	    t			       	;; choppable
	    0				;; separation
	    "center"			;; justification
	    techParam("METAL2E2")-techParam("VIA1E2")   ;; beginOffset
	    techParam("METAL2E2")-techParam("VIA1E2") 	;; endOffset
	   )
       )
       
      ;; enclosure subpath
	  nil

      ;; subrectangles
      (
	 (
	    ("Via1" "drawing")    	;; layer
	    techParam("VIA1W1")	;; width
	    techParam("VIA1W1")	;; length
	    t				;; choppable
	    0				;; separation
	    "center"			;; justification
	    techParam("VIA1S1")	;; space
	    -techParam("VIA1E2")	;; beginOffset
	    -techParam("VIA1E2")	;; endOffset
	    "distribute"       		;; gap
	 )
      )
    ) ;; M1_M2
    
 (Metal1_8x_bus
    (("Metal1" "drawing"))
    ((("Metal1" "drawing")	nil	t	0.24)
     (("Metal1" "drawing")	nil	t	0.48)
     (("Metal1" "drawing")	nil	t	0.72)
     (("Metal1" "drawing")	nil	t	0.96)
     (("Metal1" "drawing")	nil	t	1.2)
     (("Metal1" "drawing")	nil	t	1.44)
     (("Metal1" "drawing")	nil	t	1.68)
    )
    nil
    nil
  )

 ; (slotbus 
 ;   (("Metal1" "drawing")	5.0	t	nil	nil	nil	right	1.0)
 ;   ((("Metal1" "drawing")	5.0	t	2.0	right)
 ;   )
 ;   nil
 ;   ((("Metal1" "drawing")	2.0	10.0	t	nil	right	10.0)
 ;   )
 ; )

 ) ;lxMPPTemplates

) ;lxRules

leRules(
) ;leRules

;********************************
; P&R RULES
;********************************
prRules(

 prRoutingLayers(
 ;( layer                       preferredDirection  )
 ;( -----                       ------------------  )
  ( Metal1                   	"horizontal" )
  ( Metal2                   	"vertical" )
  ( Metal3                   	"horizontal" )
  ( Metal4                   	"vertical" )
  ( Metal5                   	"horizontal" )
  ( Metal6                   	"vertical" )
  ( Metal7                   	"horizontal" )
  ( Metal8                   	"vertical" )
  ( Metal9                   	"horizontal" )
 ) ;prRoutingLayers

 prViaTypes(
 ;( device viewName             viaType    )
 ;( ---------------             -------    )
  ( ("M1_PO" "symbolic")  "default"  )
  ( ("M2_M1" "symbolic")  "default"  )
  ( ("M3_M2" "symbolic")  "default"  )
  ( ("M4_M3" "symbolic")  "default"  )
  ( ("M5_M4" "symbolic")  "default"  )
  ( ("M6_M5" "symbolic")  "default"  )
  ( ("M7_M6" "symbolic")  "default"  )
  ( ("M8_M7" "symbolic")  "default"  )
  ( ("M9_M8" "symbolic")  "default"  )
 ) ;prViaTypes

 prMastersliceLayers(
 ;( layers : listed in order of lowest (closest to substrate) to highest )
 ;( -------------------------------------------------------------------- )
  ( Oxide Poly      )
 ) ;prMastersliceLayers

 prRoutingPitch(
 ;( layer                pitch )
 ;( -----                ----- )
  ( Metal1               0.29 )
  ( Metal2               0.29 )
  ( Metal3               0.29 )
  ( Metal4               0.29 )
  ( Metal5               0.29 )
  ( Metal6               0.29 )
  ( Metal7               0.29 )
  ( Metal8               0.87 )
  ( Metal9               0.87 )
 ) ;prRoutingPitch

 prRoutingOffset(
 ;( layer                offset )
 ;( -----                ------ )
  ( Metal1               0.145 )
  ( Metal2               0.145 )
  ( Metal3               0.145 )
  ( Metal4               0.145 )
  ( Metal5               0.145 )
  ( Metal6               0.145 )
  ( Metal7               0.145 )
  ( Metal8               0.435 )
  ( Metal9               0.435 )
 ) ;prRoutingOffset

 prOverlapLayer(
 ;( list of layers or layer/purpose pairs )
 ;( ------------------------------------- )
  ( OVERLAP )
 ) ;prOverlapLayer

 prStackVias(
 ;( viaLayerPairList    stackable )
 ;( ----------------    ---------- )
  ( Metal1 Metal1 )
  ( Metal2 Metal2 )
  ( Metal3 Metal3 )
  ( Metal4 Metal4 )
  ( Metal5 Metal5 )
  ( Metal6 Metal6 )
  ( Metal7 Metal7 )
  ( Metal8 Metal8 )
  ( Metal9 Metal9 )
  ( Via1 Via2 )
  ( Via2 Via3 )
  ( Via3 Via4 )
  ( Via4 Via5 )
  ( Via5 Via6 )
  ( Via6 Via7 )
  ( Via7 Via8 )
 ) ; prStackVias

 prMaxStackVias(
 ;( MaxStackVias    viaLayerPairList )
 ;( ------------    ---------------- )
  ( 4           Metal1       Metal7      )
 ) ;prMaxStackVias

 prViaRules(
 ;( ViaRuleName         viaDeviceName(s) 
 ;    layer1            direction       (wMin wMax overHang metalOverHang) 
 ;    layer2            direction       (wMin wMax overHang metalOverHang) 
 ;    (properties)
 ;) 
 ;( ---------------------------------------------------------------------- ) 
 ) ;prViaRules

 prGenViaRules(
 ;( ViaRuleName         viaLayer     (lowerPt upperPt xPitch yPitch resistence) 
 ;    Layer1            Direction|(overhang1 overhang2)    (wMin wMax overHang metalOverHang) 
 ;    Layer2            Direction|(overhang1 overhang2)    (wMin wMax overHang metalOverHang) 
 ;    (properties)
 ;) 
 ;( ---------------------------------------------------------------------- ) 
 ) ;prGenViaRules

) ;prRules
